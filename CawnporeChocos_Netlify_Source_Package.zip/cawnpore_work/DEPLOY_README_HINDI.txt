THE CAWNPORE CHOCOS - NETLIFY DEPLOY

Yeh SOURCE PROJECT hai, ready-made dist folder nahi.

Netlify par deploy karne ke liye:
Build command: npm run build
Publish directory: dist

Agar GitHub se Netlify connect karte hain, to repository ke root folder ko deploy karein.

Zaroori:
- Purani live website ko delete na karein.
- Is source ZIP ko Netlify ke manual drag-and-drop deploy mein seedha upload na karein.
- WhatsApp number source mein 916386590007 hai.
- Build command chalne ke baad dist folder banega; manual deploy mein sirf dist folder upload hota hai.
