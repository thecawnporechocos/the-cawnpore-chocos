import React, { useState, useEffect } from 'react';
import { PRODUCTS } from './data/products';
import { CartItem, Product, ProductCategory, FestivalTag } from './types/chocolate';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { EnquiryDrawer } from './components/EnquiryDrawer';
import { SearchModal } from './components/SearchModal';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { GoogleReviewsSection } from './components/GoogleReviewsSection';
import { SEOHead } from './components/SEOHead';
import { motion } from 'framer-motion';
import { HomePage } from './pages/HomePage';
import { ChocolatesPage } from './pages/ChocolatesPage';
import { HampersPage } from './pages/HampersPage';
import { FestivalPage } from './pages/FestivalPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { OrderTrackingPage } from './pages/OrderTrackingPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<ProductCategory>('all');
  const [activeFestivalTab, setActiveFestivalTab] = useState<FestivalTag>('diwali');
  
  // Selected product for the detail modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Enquiry Bag (Cart) State with LocalStorage
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('cawnpore_enquiry_bag');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('cawnpore_enquiry_bag', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to sync bag to storage', e);
    }
  }, [cartItems]);

  // Handle URL hash changes for deep linking (e.g. #chocolates, #hampers, #product=cawnpore-gold-truffles)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash.startsWith('product=')) {
        const prodId = hash.replace('product=', '');
        const found = PRODUCTS.find((p) => p.id === prodId);
        if (found) {
          setSelectedProduct(found);
        }
      } else if (['home', 'chocolates', 'hampers', 'festivals', 'track-order', 'about', 'contact'].includes(hash)) {
        setCurrentPage(hash);
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleNavigate = (page: string, filter?: string) => {
    setCurrentPage(page);
    window.location.hash = page;
    if (filter) {
      if (['all', 'dark-single-origin', 'bonbons-truffles', 'indian-infusions', 'milk-nuts', 'gift-hampers', 'festive-specials'].includes(filter)) {
        setActiveCategoryFilter(filter as ProductCategory);
      }
      if (['diwali', 'christmas', 'birthday', 'weddings', 'anniversary', 'roka', 'childrens-day', 'all-occasions'].includes(filter)) {
        setActiveFestivalTab(filter as FestivalTag);
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    window.location.hash = `product=${product.id}`;
  };

  const handleCloseProductModal = () => {
    setSelectedProduct(null);
    window.location.hash = currentPage;
  };

  const handleAddToCart = (product: Product, quantity = 1, customNote?: string) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex((item) => item.product.id === product.id);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        if (customNote) updated[existingIdx].customNote = customNote;
        return updated;
      } else {
        return [...prev, { product, quantity, customNote }];
      }
    });
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const totalCartCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#120905] text-[#f4ede4]">
      {/* Dynamic SEO & Social Head Management */}
      <SEOHead currentPage={currentPage} selectedProduct={selectedProduct} />

      {/* Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Main Page Routing */}
      <motion.main 
        className="flex-1"
        key={currentPage}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        {currentPage === 'home' && (
          <HomePage
            products={PRODUCTS}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'chocolates' && (
          <ChocolatesPage
            products={PRODUCTS}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            initialCategory={activeCategoryFilter}
          />
        )}

        {currentPage === 'hampers' && (
          <HampersPage
            products={PRODUCTS}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
          />
        )}

        {currentPage === 'festivals' && (
          <FestivalPage
            products={PRODUCTS}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            initialFestival={activeFestivalTab}
          />
        )}

        {currentPage === 'about' && <AboutPage />}

        {currentPage === 'track-order' && <OrderTrackingPage />}

        {currentPage === 'contact' && <ContactPage />}
      </motion.main>

      {/* Product Detail Modal View for Every Product */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={handleCloseProductModal}
        onAddToCart={handleAddToCart}
      />

      {/* Enquiry Bag Drawer */}
      <EnquiryDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onNavigateToShop={() => handleNavigate('chocolates')}
      />

      {/* Real-Time Product Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={PRODUCTS}
        onSelectProduct={handleSelectProduct}
      />

      {/* Floating Direct WhatsApp Button */}
      <WhatsAppFloatingButton />

      {/* Google Reviews Section (Above Footer) */}
      <GoogleReviewsSection />

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
