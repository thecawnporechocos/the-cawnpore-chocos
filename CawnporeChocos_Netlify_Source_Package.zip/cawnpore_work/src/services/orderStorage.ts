import { CartItem } from '../types/chocolate';

export interface OrderSubmissionPayload {
  orderId?: string;
  customerName?: string;
  phone?: string;
  phoneNumber?: string;
  mobile?: string;
  city?: string;
  deliveryCity?: string;
  address?: string;
  pincode?: string;
  locality?: string;
  items?: CartItem[];
  itemsSummary?: string;
  itemCount?: number;
  totalAmount?: number;
  notes?: string;
  customNote?: string;
  message?: string;
  source?: string;
}

export interface SubmissionResponse {
  success: boolean;
  orderId: string;
}

export interface SavedOrderRecord {
  orderId: string;
  timestamp: string;
  date: string;
  time: string;
  customerName: string;
  phone: string;
  itemsSummary: string;
  totalAmount: string;
  status: 'Order Confirmed' | 'Batch Preparation' | 'Packed with Cold Gel Packs' | 'Out for Kanpur Delivery' | 'Delivered';
  estimatedDelivery: string;
  city: string;
  address?: string;
  notes?: string;
}

const LOCAL_STORAGE_ORDERS_KEY = 'cawnpore_placed_orders_history';

export function getRecentLocalOrders(): SavedOrderRecord[] {
  try {
    const saved = localStorage.getItem(LOCAL_STORAGE_ORDERS_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveLocalOrder(record: SavedOrderRecord) {
  try {
    const existing = getRecentLocalOrders();
    const filtered = existing.filter((order) => order.orderId !== record.orderId);
    localStorage.setItem(LOCAL_STORAGE_ORDERS_KEY, JSON.stringify([record, ...filtered].slice(0, 20)));
  } catch (error) {
    console.error('Failed to save local order record', error);
  }
}

/** Creates an order reference and stores its tracking details only in this browser.
 * The customer completes the order by sending the prepared WhatsApp message.
 * No external order database or email service is contacted.
 */
export function createLocalOrderRecord(orderData: OrderSubmissionPayload): SubmissionResponse {
  const now = new Date();
  const orderId = orderData.orderId ||
    `CC-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;

  const itemsSummary = orderData.itemsSummary ||
    (orderData.items?.length
      ? orderData.items.map((item) => `${item.product.name} (${item.product.weight}) × ${item.quantity}`).join(' | ')
      : 'Assorted Confections');
  const total = orderData.totalAmount !== undefined
    ? orderData.totalAmount
    : (orderData.items || []).reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const phone = orderData.mobile?.trim() || orderData.phone?.trim() || orderData.phoneNumber?.trim() || 'Provided on WhatsApp';
  const city = orderData.city?.trim() || orderData.deliveryCity?.trim() || 'Kanpur';
  const address = orderData.address?.trim() || '';
  const notes = orderData.notes?.trim() || orderData.customNote?.trim() || orderData.message?.trim() || '';

  saveLocalOrder({
    orderId,
    timestamp: now.toISOString(),
    date: now.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric' }),
    time: now.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit' }),
    customerName: orderData.customerName?.trim() || 'Valued Customer',
    phone,
    itemsSummary,
    totalAmount: `₹${total.toLocaleString('en-IN')}`,
    status: 'Order Confirmed',
    estimatedDelivery: 'Please confirm availability and delivery timing with us on WhatsApp.',
    city,
    address,
    notes,
  });

  return { success: true, orderId };
}

export function lookupOrderStatus(inputOrderId: string): SavedOrderRecord {
  const cleanId = inputOrderId.trim().toUpperCase();
  const matched = getRecentLocalOrders().find((order) => order.orderId.toUpperCase() === cleanId);
  if (matched) return matched;
  throw new Error('This order reference is not saved in this browser. Please contact us on WhatsApp for help.');
}
