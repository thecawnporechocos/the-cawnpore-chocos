import React, { useState } from 'react';
import {
  ShieldCheck,
  Heart,
  Sparkles,
  MapPin,
  MessageCircle,
  Mail,
  Check,
  Truck,
  Gift,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Thermometer,
} from 'lucide-react';
import {
  BRAND_LOGO,
  STOREFRONT_IMAGE,
  ROYAL_HAMPER_IMAGE,
} from '../data/products';
import { BRAND_EMAIL, BRAND_LOCATION, DISPLAY_PHONE, WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';

interface FAQItem {
  id: string;
  category: 'delivery' | 'storage' | 'customization' | 'purity';
  question: string;
  answer: string;
  highlight?: string;
}

const FAQ_DATA: FAQItem[] = [
  // Local Delivery in Kanpur
  {
    id: 'faq-1',
    category: 'delivery',
    question: 'How does local delivery in Kanpur work? Do you offer same-day delivery?',
    answer:
      'Yes, we provide same-day local delivery across Kanpur for orders confirmed on WhatsApp before 2:00 PM IST. We cover all major localities including Civil Lines, Swaroop Nagar, Tilak Nagar, Kakadeo, Kidwai Nagar, Cantt, Arya Nagar, Govind Nagar, Mall Road, Lajpat Nagar, and Barra. Orders placed later in the day are dispatched the following morning.',
    highlight: 'Same-day delivery available across all Kanpur sectors.',
  },
  {
    id: 'faq-2',
    category: 'delivery',
    question: 'How do you ensure chocolates do not melt during transit in Kanpur?',
    answer:
      'Because pure cocoa butter melts naturally at body temperature (36°C / 97°F), all local deliveries and outstation dispatches are packed inside temperature-controlled thermal containers with food-safe insulated bubble pouches and reusable cold gel packs. This guarantees that your chocolates arrive in pristine, glossy, and unmelted condition.',
    highlight: 'Zero-melt guarantee with chilled thermal insulated packaging.',
  },
  {
    id: 'faq-3',
    category: 'delivery',
    question: 'Can I pick up my order directly from your Kanpur boutique?',
    answer:
      'Absolutely! You are always welcome to pick up your orders directly from our flagship boutique in Kanpur. You can finalize your order on WhatsApp (+91 63865 90007), and we will have your gift box or hamper beautifully packed and chilled, ready for convenient pickup at your chosen time.',
    highlight: 'Instant boutique pickup available at your convenience.',
  },

  // Chocolate Storage & Care Instructions
  {
    id: 'faq-4',
    category: 'storage',
    question: 'What is the ideal temperature and place to store your chocolates?',
    answer:
      'Our artisanal chocolates are crafted with pure cocoa butter and zero hydrogenated vegetable fats. The ideal storage temperature is between 16°C and 20°C (60°F – 68°F) in a cool, dry place with humidity below 60%. Keep the box away from direct sunlight, cooking heat, and strong-smelling spices, as cocoa butter naturally absorbs ambient aromas.',
    highlight: 'Optimal storage: 16°C – 20°C away from direct sunlight.',
  },
  {
    id: 'faq-5',
    category: 'storage',
    question: 'Can I keep The Cawnpore Chocos in the refrigerator?',
    answer:
      'If your room temperature exceeds 24°C, refrigerating the chocolates is recommended. To prevent condensation and sugar bloom, keep the box inside an airtight container or sealable zip pouch before putting it in the fridge. Most importantly, before savoring, let the chocolates sit at room temperature for 15 to 20 minutes so the silky cocoa butter can soften and release its full aroma.',
    highlight: 'Pro-tip: Rest chilled chocolates at room temp for 15 mins before eating.',
  },
  {
    id: 'faq-6',
    category: 'storage',
    question: 'What is the shelf life of your chocolates and truffles?',
    answer:
      'Our solid single-origin dark chocolate slabs, roasted nut clusters, and mendiants have a shelf life of 90 to 120 days from dispatch. Fresh ganache truffles, Kashmiri kesar medallions, and hand-painted jewel bonbons are best relished within 45 to 60 days, as they are micro-batch made without chemical stabilizers or artificial preservatives.',
    highlight: 'Slabs: 90–120 days · Fresh Truffles & Bonbons: 45–60 days.',
  },

  // Customization Options for Gift Hampers
  {
    id: 'faq-7',
    category: 'customization',
    question: 'What customization options are available for chocolate gift hampers?',
    answer:
      'We specialize in bespoke gifting for weddings, Roka ceremonies, anniversaries, birthdays, and corporate events. Customization options include: custom satin ribbon colors (Imperial Gold, Deep Brown, Festive Crimson), personalized gold-foiled family monograms, custom branded corporate sleeves, and handwritten calligraphy parchment cards with your personal greeting.',
    highlight: 'Custom ribbons, foil monograms, and personalized handwritten cards.',
  },
  {
    id: 'faq-8',
    category: 'customization',
    question: 'Can I choose specific chocolate flavours and assortment counts in my hamper?',
    answer:
      'Yes, you have full freedom to curate your box. You can choose whether you prefer 74% dark single-origin bars, Awadh saffron-pistachio medallions, roasted Mamra almond rochers, or jewel-toned fruit ganache bonbons. You can also select the box capacity (9 pcs, 16 pcs, 24 pcs, or 36 pcs) through our Gift Hampers builder or via WhatsApp.',
    highlight: '100% custom flavor selection tailored to your palate.',
  },
  {
    id: 'faq-9',
    category: 'customization',
    question: 'Is there a minimum order quantity (MOQ) for custom gifting?',
    answer:
      'For individual and family gifts, there is no minimum quantity—we are delighted to personalize even a single keepsake gift box! For custom corporate logo embossing, bulk Diwali hampers, or wedding favor boxes with personalized printed sleeves, we recommend orders of 20 to 25+ boxes for dedicated branding.',
    highlight: 'No MOQ for personal gifting; bulk privileges for 20+ hampers.',
  },

  // Purity & Vegetarian Guarantee
  {
    id: 'faq-10',
    category: 'purity',
    question: 'Are all The Cawnpore Chocos products strictly 100% vegetarian (eggless)?',
    answer:
      'Yes! Every single product handcrafted at The Cawnpore Chocos is 100% vegetarian and completely eggless. We never use animal-derived gelatin, egg whites, or animal fats. Furthermore, we never use compound chocolate, vegetable oils, or hydrogenated vanaspati—only pure cocoa butter and natural botanicals.',
    highlight: '100% Vegetarian (Eggless) · Pure Cocoa Butter Guarantee.',
  },
];

export const AboutPage: React.FC = () => {
  const [activeFaqTab, setActiveFaqTab] = useState<'all' | 'delivery' | 'storage' | 'customization' | 'purity'>('all');
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');

  const filteredFaqs = activeFaqTab === 'all'
    ? FAQ_DATA
    : FAQ_DATA.filter((item) => item.category === activeFaqTab);

  const toggleFaq = (id: string) => {
    setOpenFaqId((prev) => (prev === id ? null : id));
  };

  const handleCustomQuestionWhatsApp = () => {
    const text = 'Namaste The Cawnpore Chocos! I have a question regarding your chocolates, delivery in Kanpur, or custom gift hampers.';
    window.open(buildWhatsAppUrl(text), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-20 py-12 pb-24">
      
      {/* 1. Header Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-3xl space-y-4">
        <div className="inline-flex items-center gap-2 bg-[#1a0e08] border border-[#c9a44c]/40 rounded-full px-4 py-1 mb-2">
          <img
            src={BRAND_LOGO}
            alt="The Cawnpore Chocos"
            className="w-5 h-5 object-contain"
          />
          <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
            Every Occasion, A Sweet Expression
          </span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4] leading-tight">
          Handcrafted in the Historic City of Cawnpore
        </h1>
        <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
          The Cawnpore Chocos was born in Kanpur, Uttar Pradesh, with a singular dedication: to restore the purity, craft, and romance of true artisanal chocolate making in India.
        </p>
      </section>

      {/* 2. Visual Story Grid with Real Kanpur Storefront */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#42281b] shadow-2xl bg-[#120905]">
            <img
              src={STOREFRONT_IMAGE}
              alt="The Cawnpore Chocos Flagship Boutique in Kanpur"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#120905]/80 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 text-xs text-[#f4ede4] font-medium">
              <span className="text-[#e2c678] font-semibold block text-[10px] uppercase">Kanpur Boutique</span>
              The Cawnpore Chocos - Handmade Chocolates
            </div>
          </div>

          <div className="space-y-6">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
              The Craftsmanship Standard
            </span>

            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4]">
              Pure Cocoa Butter. Zero Palm Oil.
            </h2>

            <div className="space-y-4 text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
              <p>
                In an era where industrial mass confectionery substitutes cocoa butter with hydrogenated palm oil and chemical hardeners, we adhere strictly to the classic European standard of chocolate confectionery.
              </p>
              <p>
                Pure cocoa butter melts naturally at body temperature (36°C / 97°F). This is what creates that velvety, lingering mouthfeel that artificial compound fats can never replicate.
              </p>
              <p>
                Every batch at The Cawnpore Chocos is stone-ground for over 36 hours, naturally aerated, and hand-tempered by skilled confectioners right here in Kanpur, Uttar Pradesh.
              </p>
            </div>

            <div className="pt-2 grid grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-[#1a0e08] rounded-xl border border-[#2d1b11]">
                <span className="font-serif text-lg font-bold text-[#e2c678] block">36+ Hours</span>
                <span className="text-[#d8c2ad]/70 mt-1 block">Slow Granite Stone Conching</span>
              </div>
              <div className="p-4 bg-[#1a0e08] rounded-xl border border-[#2d1b11]">
                <span className="font-serif text-lg font-bold text-[#e2c678] block">100% Eggless</span>
                <span className="text-[#d8c2ad]/70 mt-1 block">Pure Vegetarian Confectionery</span>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 3. Real Packaging & Gifting Excellence */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="order-2 lg:order-1 space-y-6">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
              Signature Presentation
            </span>

            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4]">
              Authentic Rigid Boxes & Gold Foil Detailing
            </h2>

            <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
              Every box leaving our Kanpur studio is an experience of tactile luxury. Hand-assembled rigid boxes hot-stamped in gold with The Cawnpore Chocos seal, double-satin ribbons, and food-safe gold compartment trays that protect each bonbon in transit.
            </p>

            <div className="space-y-3 pt-2 text-xs text-[#d8c2ad]">
              <div className="flex items-center gap-2.5">
                <Check className="w-4 h-4 text-[#c9a44c]" />
                <span>Certified food-safe European packaging with gold foil embossing</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Check className="w-4 h-4 text-[#c9a44c]" />
                <span>Personalized handwritten parchment cards for gifts & celebrations</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Check className="w-4 h-4 text-[#c9a44c]" />
                <span>Insulated temperature packaging for all-India courier dispatches</span>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#42281b] shadow-2xl bg-[#120905]">
            <img
              src={ROYAL_HAMPER_IMAGE}
              alt="The Cawnpore Chocos Handcrafted Rigid Gift Box"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute bottom-4 left-4 right-4 text-xs text-[#f4ede4] font-medium">
              <span className="text-[#e2c678] font-semibold block text-[10px] uppercase">Crafted With Care</span>
              Gloved Chocolatier Presentation Box
            </div>
          </div>

        </div>
      </section>

      {/* 4. The Indian Terroir & Botanicals */}
      <section className="bg-[#160c07] border-y border-[#2d1b11] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block mb-1">
              Ingredients With Soul
            </span>
            <h2 className="font-serif text-3xl font-semibold text-[#f4ede4]">
              The Indian Terroir
            </h2>
            <p className="text-xs sm:text-sm text-[#d8c2ad]/80 mt-2">
              We celebrate fine South Indian single-estate cocoa beans paired with the most exquisite botanicals from the subcontinent.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl bg-[#120905] border border-[#2d1b11] space-y-3">
              <h3 className="font-serif text-lg font-semibold text-[#e2c678]">
                Kashmiri Saffron (Kesar)
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Hand-harvested crimson stigmas steeped gently in pure cocoa butter, lending golden warmth and aristocratic fragrance to our Awadh collection.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#120905] border border-[#2d1b11] space-y-3">
              <h3 className="font-serif text-lg font-semibold text-[#e2c678]">
                Whole Mamra Almonds & Pistachios
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Oven-roasted in small batches to preserve natural oils and snap. Coated in caramelized cane sugar and draped in dark chocolate.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#120905] border border-[#2d1b11] space-y-3">
              <h3 className="font-serif text-lg font-semibold text-[#e2c678]">
                Cardamom & Arabica Espresso
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Slow-roasted Chikmagalur coffee beans ground with crushed green cardamom pods for an invigorating Indian culinary harmony.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. NEW: FREQUENTLY ASKED QUESTIONS (FAQ) SECTION */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
            <HelpCircle className="w-4 h-4 text-[#c9a44c]" />
            <span>Customer Guidance & Answers</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4]">
            Frequently Asked Questions
          </h2>
          <p className="text-xs sm:text-sm text-[#d8c2ad]/80">
            Clear insights regarding our Kanpur local delivery, pure cocoa butter storage care, and bespoke gift hamper customization.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-8">
          {[
            { id: 'all', label: 'All Questions' },
            { id: 'delivery', label: 'Kanpur Delivery', icon: Truck },
            { id: 'storage', label: 'Storage & Care', icon: Thermometer },
            { id: 'customization', label: 'Gift Customization', icon: Gift },
            { id: 'purity', label: 'Vegetarian & Purity', icon: ShieldCheck },
          ].map((tab) => {
            const isActive = activeFaqTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveFaqTab(tab.id as any)}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-[#c9a44c] text-[#120905] border-[#c9a44c] shadow-md font-bold'
                    : 'bg-[#1a0e08] text-[#d8c2ad] border-[#2d1b11] hover:border-[#42281b] hover:text-[#f4ede4]'
                }`}
              >
                {Icon && <Icon className="w-3.5 h-3.5" />}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3.5">
          {filteredFaqs.map((faq) => {
            const isOpen = openFaqId === faq.id;
            return (
              <div
                key={faq.id}
                className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#1a0e08] border-[#c9a44c]/60 shadow-lg'
                    : 'bg-[#120905] border-[#2d1b11] hover:border-[#42281b]'
                }`}
              >
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full px-5 sm:px-6 py-4.5 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className={`font-serif text-base sm:text-lg font-semibold transition-colors ${
                    isOpen ? 'text-[#e2c678]' : 'text-[#f4ede4] hover:text-[#e2c678]'
                  }`}>
                    {faq.question}
                  </span>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border transition-transform duration-200 ${
                    isOpen
                      ? 'bg-[#23140c] border-[#c9a44c] text-[#e2c678]'
                      : 'bg-[#1a0e08] border-[#2d1b11] text-[#d8c2ad]'
                  }`}>
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-xs text-[#d8c2ad] leading-relaxed border-t border-[#2d1b11]/60 space-y-3 animate-in fade-in duration-200">
                    <p>{faq.answer}</p>
                    {faq.highlight && (
                      <div className="inline-flex items-center gap-2 bg-[#23140c] border border-[#42281b] px-3 py-1.5 rounded text-[11px] text-[#e2c678] font-medium">
                        <Check className="w-3.5 h-3.5 text-[#c9a44c] shrink-0" />
                        <span>{faq.highlight}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* WhatsApp FAQ Assistance Prompt Card */}
        <div className="mt-8 bg-gradient-to-r from-[#23140c] via-[#1a0e08] to-[#23140c] border border-[#c9a44c]/40 rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-serif text-lg font-semibold text-[#f4ede4]">
              Have a bespoke request or another question?
            </h4>
            <p className="text-xs text-[#d8c2ad]/80">
              Our Kanpur confectioners are active daily on WhatsApp to help with custom orders, flavors, and wedding curation.
            </p>
          </div>
          <button
            onClick={handleCustomQuestionWhatsApp}
            className="px-5 py-3 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors inline-flex items-center gap-2 shrink-0 shadow-md cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
            <span>Chat on WhatsApp (+91 63865 90007)</span>
          </button>
        </div>

      </section>

      {/* 6. Confectionery Location & Contact */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#1a0e08] rounded-2xl border border-[#42281b] p-8 sm:p-12 shadow-2xl">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
              Direct Artisanal Connection
            </span>
            <h2 className="font-serif text-3xl font-semibold text-[#f4ede4]">
              Freshly Prepared to Order in Kanpur
            </h2>
            <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
              We do not warehouse chocolates in plastic wrappers for months. Every box is prepared fresh against order confirmations and carefully packaged with temperature insulation for dispatch across India.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-6 text-xs text-[#f4ede4]">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#c9a44c]" />
                <span>{BRAND_LOCATION}</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#c9a44c]" />
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#e2c678] font-mono"
                >
                  {DISPLAY_PHONE}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#c9a44c]" />
                <a href={`mailto:${BRAND_EMAIL}`} className="hover:text-[#e2c678]">
                  {BRAND_EMAIL}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
