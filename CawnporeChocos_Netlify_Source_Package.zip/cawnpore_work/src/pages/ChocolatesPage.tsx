import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import { Product, ProductCategory } from '../types/chocolate';
import { ProductCard } from '../components/ProductCard';

interface ChocolatesPageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  initialCategory?: ProductCategory;
}

export const ChocolatesPage: React.FC<ChocolatesPageProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  initialCategory = 'all',
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'cocoa-desc'>('featured');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'pure-dark' | 'nuts'>('all');

  const categories: { id: ProductCategory; label: string }[] = [
    { id: 'all', label: 'All Confections' },
    { id: 'dark-single-origin', label: 'Single-Origin Dark' },
    { id: 'bonbons-truffles', label: 'Bonbons & Truffles' },
    { id: 'indian-infusions', label: 'Indian Spice Infusions' },
    { id: 'milk-nuts', label: 'Milk & Nut Clusters' },
    { id: 'gift-hampers', label: 'Gift Hampers' },
    { id: 'festive-specials', label: 'Festive Specials' },
  ];

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        // Category Filter
        if (selectedCategory !== 'all' && p.category !== selectedCategory) {
          return false;
        }

        // Dietary Filter
        if (dietaryFilter === 'pure-dark' && p.cocoaPercentage < 70) {
          return false;
        }
        if (dietaryFilter === 'nuts' && !p.ingredients.toLowerCase().includes('almond') && !p.ingredients.toLowerCase().includes('pistachio') && !p.ingredients.toLowerCase().includes('hazelnut')) {
          return false;
        }

        // Search Query
        if (searchQuery.trim() !== '') {
          const q = searchQuery.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          const matchNotes = p.tastingNotes.some((n) => n.toLowerCase().includes(q));
          const matchIngredients = p.ingredients.toLowerCase().includes(q);
          if (!matchName && !matchDesc && !matchNotes && !matchIngredients) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'cocoa-desc') return b.cocoaPercentage - a.cocoaPercentage;
        // Default featured
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return 0;
      });
  }, [products, selectedCategory, searchQuery, sortBy, dietaryFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      
      {/* Header Banner */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
          Artisanal Catalog
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4]">
          Our Handcrafted Chocolates
        </h1>
        <p className="text-xs sm:text-sm text-[#d8c2ad]/80">
          Pure cocoa butter bars, jewel-toned bonbons, and nut clusters prepared in small batches in Kanpur.
        </p>
      </div>

      {/* Search and Sort Toolbar */}
      <div className="bg-[#1a0e08] p-4 rounded-xl border border-[#2d1b11] flex flex-col md:flex-row gap-4 items-center justify-between">
        
        {/* Search Field */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#c9a44c] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search flavor, nut, or cocoa %..."
            className="w-full pl-9 pr-4 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-xs text-[#f4ede4] placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
          />
        </div>

        {/* Sort & Quick Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end text-xs">
          {/* Dietary Filter */}
          <div className="flex items-center gap-2">
            <span className="text-[#d8c2ad]/70 hidden sm:inline">Preference:</span>
            <select
              value={dietaryFilter}
              onChange={(e) => setDietaryFilter(e.target.value as any)}
              className="bg-[#120905] border border-[#42281b] rounded-lg px-2.5 py-2 text-xs text-[#f4ede4] focus:outline-none focus:border-[#c9a44c] cursor-pointer"
            >
              <option value="all">All Varieties</option>
              <option value="pure-dark">70%+ Dark Noir</option>
              <option value="nuts">Roasted Nuts & Rochers</option>
            </select>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-[#c9a44c]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#120905] border border-[#42281b] rounded-lg px-2.5 py-2 text-xs text-[#f4ede4] focus:outline-none focus:border-[#c9a44c] cursor-pointer"
            >
              <option value="featured">Sort: Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="cocoa-desc">Cocoa %: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Category Segmented Filter Tabs (Interactive Functional Controls per Design Skill) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer border ${
                isActive
                  ? 'bg-[#c9a44c] text-[#120905] border-[#c9a44c] shadow-sm'
                  : 'bg-[#1a0e08] text-[#d8c2ad] border-[#2d1b11] hover:border-[#42281b] hover:text-[#f4ede4]'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Results Count & Current Filter Indicators */}
      <div className="flex items-center justify-between text-xs text-[#d8c2ad]/70 border-b border-[#2d1b11] pb-3">
        <span>
          Showing <strong className="text-[#e2c678] font-normal">{filteredProducts.length}</strong> confections
        </span>
        <div className="flex items-center gap-2">
          <span>WhatsApp Orders Available for All Items</span>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-[#1a0e08] rounded-xl border border-[#2d1b11] p-12 text-center space-y-4">
          <p className="font-serif text-xl text-[#f4ede4]">No matching chocolates found</p>
          <p className="text-xs text-[#d8c2ad]/70 max-w-sm mx-auto">
            Try adjusting your search query or selecting "All Confections" to view our complete collection.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
              setDietaryFilter('all');
            }}
            className="px-4 py-2 bg-[#23140c] text-xs font-semibold text-[#e2c678] rounded-lg border border-[#42281b] hover:border-[#c9a44c] cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      )}

      {/* Custom Chocolate Inquiry Callout */}
      <div className="bg-[#160c07] rounded-xl border border-[#42281b] p-6 text-center space-y-3">
        <h3 className="font-serif text-lg font-semibold text-[#f4ede4]">
          Looking for a specific cocoa percentage or flavor profile?
        </h3>
        <p className="text-xs text-[#d8c2ad]/80 max-w-lg mx-auto">
          We craft custom micro-batches for private connoisseurs and celebrations. Discuss your custom preferences directly on WhatsApp.
        </p>
      </div>

    </div>
  );
};
