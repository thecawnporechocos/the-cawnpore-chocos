import React, { useState } from 'react';
import { Gift, Sparkles, MessageCircle, Check, ArrowRight } from 'lucide-react';
import { Product } from '../types/chocolate';
import { HAMPER_IMAGE, DIWALI_IMAGE } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { createLocalOrderRecord } from '../services/orderStorage';

interface HampersPageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const HampersPage: React.FC<HampersPageProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
}) => {
  // Filter hamper and special gift box products
  const hamperProducts = products.filter(
    (p) => p.category === 'gift-hampers' || p.category === 'festive-specials' || (p.piecesCount && p.piecesCount >= 8)
  );

  // Custom Hamper Configurator State
  const [boxTier, setBoxTier] = useState<'9-pcs' | '16-pcs' | '24-pcs' | '36-pcs'>('24-pcs');
  const [flavorTheme, setFlavorTheme] = useState('Royal Awadh Saffron, Nuts & Truffles');
  const [ribbonColor, setRibbonColor] = useState('Imperial Gold Satin');
  const [personalNote, setPersonalNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const tierPrices = {
    '9-pcs': { name: 'Petite Connoisseur Box', count: '9 Chocolates', price: 850 },
    '16-pcs': { name: 'Deluxe Heritage Box', count: '16 Chocolates', price: 1550 },
    '24-pcs': { name: 'Royal Cawnpore Rigid Hamper', count: '24 Chocolates', price: 2450 },
    '36-pcs': { name: 'Awadh Wedding Trousseau Trunk', count: '36 Chocolates', price: 3600 },
  };

  const currentTier = tierPrices[boxTier];

  const handleCustomHamperEnquiry = () => {
    setIsSubmitting(true);

    const { orderId } = createLocalOrderRecord({
      customerName: 'Custom Hamper Client',
      itemsSummary: `Custom ${currentTier.name} (${currentTier.count}) - Theme: ${flavorTheme}, Ribbon: ${ribbonColor}`,
      totalAmount: currentTier.price,
      customNote: personalNote,
      source: 'Custom Hamper Builder',
    });

    setIsSubmitting(false);

    const message = `Namaste The Cawnpore Chocos!

*Hamper Reference:* ${orderId}

I would like to enquire about a custom chocolate gift hamper:

*Selected Box:* ${currentTier.name} (${currentTier.count})
*Estimated Price:* ₹${currentTier.price.toLocaleString('en-IN')}
*Flavor Theme:* ${flavorTheme}
*Ribbon Finish:* ${ribbonColor}
${personalNote ? `*Gift Note:* ${personalNote}\n` : ''}
Please confirm availability and sharing custom packaging previews.`;

    window.open(buildWhatsAppUrl(message), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-16 py-12 pb-20">
      
      {/* 1. Header Hero with Authentic Luxury Box */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-2xl bg-[#1a0e08] border border-[#42281b] overflow-hidden grid grid-cols-1 lg:grid-cols-12 shadow-2xl">
          <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-between space-y-4">
            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
                Every Occasion, A Sweet Expression
              </span>
              <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4] leading-tight">
                Artisanal Chocolate Gift Hampers
              </h1>
              <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
                Hand-constructed keepsake boxes, double-faced satin ribbons, and artisanal confections made with pure cocoa butter and zero hydrogenated palm oil. Designed in Kanpur for grand celebrations, royal weddings, and corporate gifting.
              </p>
              <div className="pt-2 flex flex-wrap gap-4 text-xs text-[#e2c678]">
                <span>✓ 100% Pure Cocoa Butter</span>
                <span aria-hidden="true" className="text-[#5c3927]">·</span>
                <span>✓ Eggless & Pure Vegetarian</span>
                <span aria-hidden="true" className="text-[#5c3927]">·</span>
                <span>✓ Direct Dispatch from Kanpur</span>
              </div>
            </div>
          </div>
          <div className="lg:col-span-5 relative aspect-[4/3] lg:aspect-auto min-h-[280px] bg-[#120905]">
            <img
              src="/assets/aistudio/FEC5F515-3188-45EB-AA6F-6F21F170A6F0_1185a598.jpeg"
              alt="The Cawnpore Chocos Royal Rigid Hamper Box"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute top-4 right-4 bg-[#120905]/90 border border-[#c9a44c]/60 px-3 py-1 rounded text-xs text-[#e2c678] font-semibold uppercase tracking-wider">
              Authentic Rigid Box
            </div>
          </div>
        </div>
      </section>

      {/* 2. Interactive Custom Hamper Builder */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#160c07] rounded-2xl border border-[#c9a44c]/40 p-6 sm:p-10 shadow-xl">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs uppercase tracking-widest text-[#e2c678] font-semibold block mb-1">
              Curate Your Own Box
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#f4ede4]">
              Bespoke Hamper Consultant
            </h2>
            <p className="text-xs text-[#d8c2ad]/80 mt-1">
              Choose your box dimension, preferred flavor direction, and ribbon finish. Submit your custom curation directly to our confectionery on WhatsApp.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Step 1: Select Box Size */}
            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] block">
                1. Select Box Size
              </span>
              <div className="space-y-2.5">
                {(Object.keys(tierPrices) as Array<keyof typeof tierPrices>).map((key) => {
                  const tier = tierPrices[key];
                  const isSelected = boxTier === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setBoxTier(key)}
                      className={`w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#23140c] border-[#c9a44c] shadow-md'
                          : 'bg-[#120905] border-[#2d1b11] hover:border-[#42281b]'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-serif text-sm font-semibold text-[#f4ede4]">
                          {tier.name}
                        </span>
                        <span className="font-mono text-xs font-bold text-[#e2c678]">
                          ₹{tier.price.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <span className="text-[11px] text-[#d8c2ad]/70 mt-0.5 block">
                        {tier.count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Flavor Theme & Packaging */}
            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] block">
                2. Flavor & Ribbon Styling
              </span>
              
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1">Flavor Direction</label>
                  <select
                    value={flavorTheme}
                    onChange={(e) => setFlavorTheme(e.target.value)}
                    className="w-full bg-[#120905] border border-[#42281b] rounded-lg p-2.5 text-xs text-[#f4ede4] focus:outline-none focus:border-[#c9a44c] cursor-pointer"
                  >
                    <option value="Royal Awadh Saffron, Nuts & Truffles">Royal Awadh Saffron, Nuts & Truffles</option>
                    <option value="74%+ Single-Origin Dark Noir Flight">74%+ Single-Origin Dark Noir Flight</option>
                    <option value="Festive Bonbon & Praline Assortment">Festive Bonbon & Praline Assortment</option>
                    <option value="Roasted Nut Rochers & Florentines">Roasted Nut Rochers & Florentines</option>
                    <option value="Mild Creamy Milk & Honey Drops (Kids Friendly)">Mild Creamy Milk & Honey Drops (Kids Friendly)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1">Ribbon Finish</label>
                  <select
                    value={ribbonColor}
                    onChange={(e) => setRibbonColor(e.target.value)}
                    className="w-full bg-[#120905] border border-[#42281b] rounded-lg p-2.5 text-xs text-[#f4ede4] focus:outline-none focus:border-[#c9a44c] cursor-pointer"
                  >
                    <option value="Imperial Gold Satin">Imperial Gold Satin</option>
                    <option value="Deep Chocolate Brown Satin">Deep Chocolate Brown Satin</option>
                    <option value="Royal Festive Crimson">Royal Festive Crimson</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1">Personal Gift Message / Instructions</label>
                  <textarea
                    rows={2}
                    value={personalNote}
                    onChange={(e) => setPersonalNote(e.target.value)}
                    placeholder="e.g. For Mrs. Sharma, Kanpur. Include Congratulations card."
                    className="w-full bg-[#120905] border border-[#42281b] rounded-lg p-2.5 text-xs text-[#f4ede4] placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>
            </div>

            {/* Step 3: Summary & Direct WhatsApp Inquiry */}
            <div className="bg-[#120905] rounded-xl border border-[#2d1b11] p-5 flex flex-col justify-between">
              <div className="space-y-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] block">
                  3. Hamper Summary
                </span>
                
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-[#d8c2ad]">
                    <span>Box:</span>
                    <span className="text-[#f4ede4] font-medium text-right">{currentTier.name}</span>
                  </div>
                  <div className="flex justify-between text-[#d8c2ad]">
                    <span>Capacity:</span>
                    <span className="text-[#f4ede4] font-medium">{currentTier.count}</span>
                  </div>
                  <div className="flex justify-between text-[#d8c2ad]">
                    <span>Theme:</span>
                    <span className="text-[#e2c678] font-medium text-right max-w-[60%] truncate">{flavorTheme}</span>
                  </div>
                  <div className="flex justify-between text-[#d8c2ad]">
                    <span>Ribbon:</span>
                    <span className="text-[#f4ede4] font-medium">{ribbonColor}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#2d1b11] flex justify-between items-baseline">
                  <span className="text-xs text-[#d8c2ad]">Estimated Total:</span>
                  <span className="font-mono tabular-nums text-xl font-bold text-[#e2c678]">
                    ₹{currentTier.price.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <div className="pt-4 space-y-2">
                <button
                  onClick={handleCustomHamperEnquiry}
                  disabled={isSubmitting}
                  className="w-full py-3 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-semibold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors shadow-md cursor-pointer disabled:opacity-60"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>
                    {isSubmitting ? 'Syncing Hamper Details...' : 'Enquire This Box on WhatsApp'}
                  </span>
                </button>
                <p className="text-[10px] text-center text-[#d8c2ad]/60">
                  Bulk discounts available for orders above 25 boxes.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Pre-Curated Luxury Gift Hampers Catalog */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="border-b border-[#2d1b11] pb-4">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block mb-1">
            Ready-to-Order Assortments
          </span>
          <h2 className="font-serif text-3xl font-semibold text-[#f4ede4]">
            Pre-Curated Luxury Hampers
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {hamperProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

    </div>
  );
};
