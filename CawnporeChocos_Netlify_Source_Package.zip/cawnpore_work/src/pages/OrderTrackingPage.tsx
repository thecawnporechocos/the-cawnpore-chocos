import React, { useState, useEffect } from 'react';
import {
  Search,
  Truck,
  CheckCircle,
  Clock,
  MapPin,
  MessageCircle,
  PackageCheck,
  ShieldCheck,
  Thermometer,
  AlertCircle,
  History,
  ChevronRight,
} from 'lucide-react';
import {
  lookupOrderStatus,
  getRecentLocalOrders,
  SavedOrderRecord,
} from '../services/orderStorage';
import { WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { BRAND_LOGO } from '../data/products';

export const OrderTrackingPage: React.FC = () => {
  const [orderInput, setOrderInput] = useState('');
  const [searchedId, setSearchedId] = useState<string | null>(null);
  const [orderRecord, setOrderRecord] = useState<SavedOrderRecord | null>(null);
  const [loading, setLoading] = useState(false);
  const [recentOrders, setRecentOrders] = useState<SavedOrderRecord[]>([]);

  useEffect(() => {
    const history = getRecentLocalOrders();
    setRecentOrders(history);
    if (history.length > 0) {
      setOrderRecord(history[0]);
      setSearchedId(history[0].orderId);
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderInput.trim()) return;

    setLoading(true);
    setSearchedId(orderInput.trim().toUpperCase());
    const result = lookupOrderStatus(orderInput.trim());
    setOrderRecord(result);
    setLoading(false);
  };

  const handleSelectRecent = (order: SavedOrderRecord) => {
    setOrderRecord(order);
    setSearchedId(order.orderId);
    setOrderInput(order.orderId);
  };

  const handleWhatsAppStatusInquiry = () => {
    if (!orderRecord) return;
    const msg = `Namaste The Cawnpore Chocos!
I would like an update on my order:
*Order Reference:* ${orderRecord.orderId}
*Customer Name:* ${orderRecord.customerName}
*Status:* ${orderRecord.status}
Kindly let me know the estimated rider dispatch time in Kanpur. Thank you!`;
    window.open(buildWhatsAppUrl(msg), '_blank', 'noopener,noreferrer');
  };

  // Delivery status step determination
  const deliverySteps = [
    {
      title: 'Order Confirmed',
      description: 'Order reference saved in this browser; confirm your order with us on WhatsApp',
      icon: CheckCircle,
      stepKey: 'Order Confirmed',
    },
    {
      title: 'Batch Preparation',
      description: 'Handcrafting pure cocoa butter chocolates in Kanpur',
      icon: Clock,
      stepKey: 'Batch Preparation',
    },
    {
      title: 'Thermal Insulated Packing',
      description: 'Chilled gel packs & gold-stamped rigid box seal',
      icon: Thermometer,
      stepKey: 'Packed with Cold Gel Packs',
    },
    {
      title: 'Out for Kanpur Delivery',
      description: 'Express rider in transit to your Kanpur location',
      icon: Truck,
      stepKey: 'Out for Kanpur Delivery',
    },
    {
      title: 'Delivered Fresh',
      description: 'Handed over directly with temperature care label',
      icon: PackageCheck,
      stepKey: 'Delivered',
    },
  ];

  const currentStatusIndex = orderRecord
    ? deliverySteps.findIndex((s) => s.stepKey === orderRecord.status) >= 0
      ? deliverySteps.findIndex((s) => s.stepKey === orderRecord.status)
      : 3 // Default to Out for Delivery for demo
    : -1;

  return (
    <div className="space-y-16 py-12 pb-24">
      {/* 1. Page Header */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-[#1a0e08] border border-[#c9a44c]/40 rounded-full px-4 py-1 mb-2 shadow-md">
          <img
            src={BRAND_LOGO}
            alt="The Cawnpore Chocos"
            className="w-5 h-5 object-contain"
          />
          <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
            Kanpur Local Delivery Tracker
          </span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4] leading-tight">
          Track Your Chocolate Delivery
        </h1>
        <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed max-w-xl mx-auto">
          Enter your Order Reference ID (e.g. <code className="text-[#e2c678] font-mono">CC-202611-4821</code>) or contact number to view live batch preparation and delivery status across Kanpur.
        </p>
      </section>

      {/* 2. Order ID Search Form */}
      <section className="max-w-2xl mx-auto px-4 sm:px-6">
        <form onSubmit={handleSearch} className="relative flex items-center">
          <input
            type="text"
            value={orderInput}
            onChange={(e) => setOrderInput(e.target.value)}
            placeholder="Enter Order ID (e.g. CC-202611-1234 or Phone Number)..."
            className="w-full bg-[#1a0e08] border border-[#42281b] focus:border-[#c9a44c] rounded-xl px-5 py-4 pl-12 pr-32 text-sm text-[#f4ede4] placeholder-[#d8c2ad]/50 focus:outline-none transition-all shadow-xl font-mono"
            required
          />
          <Search className="absolute left-4 w-5 h-5 text-[#c9a44c]" />
          <button
            type="submit"
            disabled={loading}
            className="absolute right-2.5 px-5 py-2.5 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer flex items-center gap-2"
          >
            {loading ? (
              <span>Checking...</span>
            ) : (
              <>
                <span>Track Order</span>
                <ChevronRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Recent Orders Selection Pills */}
        {recentOrders.length > 0 && (
          <div className="mt-4 pt-3 border-t border-[#2d1b11] flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-[#d8c2ad]/70 flex items-center gap-1 font-medium">
              <History className="w-3.5 h-3.5 text-[#c9a44c]" />
              Recent Orders:
            </span>
            {recentOrders.slice(0, 3).map((ord) => (
              <button
                key={ord.orderId}
                onClick={() => handleSelectRecent(ord)}
                className={`text-[11px] font-mono px-3 py-1 rounded-full border transition-all cursor-pointer ${
                  searchedId === ord.orderId
                    ? 'bg-[#c9a44c] text-[#120905] border-[#c9a44c] font-bold'
                    : 'bg-[#120905] text-[#e2c678] border-[#2d1b11] hover:border-[#c9a44c]/60'
                }`}
              >
                {ord.orderId}
              </button>
            ))}
          </div>
        )}
      </section>

      {/* 3. Order Status Display Card */}
      {orderRecord && (
        <section className="max-w-3xl mx-auto px-4 sm:px-6">
          <div className="bg-[#1a0e08] border border-[#42281b] rounded-2xl p-6 sm:p-8 space-y-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#c9a44c]/5 rounded-full blur-3xl pointer-events-none" />

            {/* Order Summary Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#2d1b11]">
              <div className="space-y-1">
                <span className="text-[10px] uppercase tracking-widest text-[#e2c678] font-semibold block">
                  Saved on this device
                </span>
                <div className="flex items-center gap-3">
                  <h2 className="font-serif text-2xl font-bold text-[#f4ede4] font-mono">
                    {orderRecord.orderId}
                  </h2>
                  <span className="px-3 py-0.5 rounded-full text-[11px] font-semibold bg-[#23140c] border border-[#c9a44c]/50 text-[#e2c678]">
                    {orderRecord.status}
                  </span>
                </div>
                <p className="text-xs text-[#d8c2ad]/80">
                  Customer: <strong className="text-[#f4ede4]">{orderRecord.customerName}</strong> · Placed on {orderRecord.date} at {orderRecord.time}
                </p>
              </div>

              <div className="text-left sm:text-right space-y-1">
                <span className="text-xs text-[#d8c2ad]/70 block">Total Order Amount</span>
                <span className="font-serif text-xl font-bold text-[#e2c678]">
                  {orderRecord.totalAmount}
                </span>
                <span className="text-[11px] text-[#d8c2ad]/60 block">
                  {orderRecord.city || 'Kanpur'} Delivery
                </span>
              </div>
            </div>

            {/* Items Included */}
            <div className="p-4 rounded-xl bg-[#120905] border border-[#2d1b11] space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-[#e2c678] font-semibold block">
                Items Summary
              </span>
              <p className="text-xs text-[#f4ede4] font-medium leading-relaxed">
                {orderRecord.itemsSummary}
              </p>
              {orderRecord.notes && (
                <p className="text-[11px] text-[#d8c2ad]/80 italic pt-1">
                  Note: "{orderRecord.notes}"
                </p>
              )}
            </div>

            {/* Step-by-Step Delivery Progress Timeline */}
            <div className="space-y-6 pt-2">
              <h3 className="font-serif text-lg font-semibold text-[#f4ede4] flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#c9a44c]" />
                <span>Live Delivery Progress</span>
              </h3>

              <div className="relative pl-6 space-y-8 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#2d1b11]">
                {deliverySteps.map((step, idx) => {
                  const isCompleted = idx <= currentStatusIndex;
                  const isCurrent = idx === currentStatusIndex;
                  const Icon = step.icon;

                  return (
                    <div key={step.stepKey} className="relative flex items-start gap-4 group">
                      {/* Step Indicator Dot / Icon */}
                      <div
                        className={`absolute -left-6 w-5 h-5 rounded-full flex items-center justify-center border text-[10px] font-bold transition-all ${
                          isCompleted
                            ? 'bg-[#c9a44c] border-[#c9a44c] text-[#120905]'
                            : 'bg-[#120905] border-[#2d1b11] text-[#d8c2ad]/40'
                        }`}
                      >
                        {isCompleted ? '✓' : idx + 1}
                      </div>

                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-serif text-base font-semibold ${
                              isCurrent
                                ? 'text-[#e2c678]'
                                : isCompleted
                                ? 'text-[#f4ede4]'
                                : 'text-[#d8c2ad]/50'
                            }`}
                          >
                            {step.title}
                          </span>
                          {isCurrent && (
                            <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded bg-[#c9a44c]/20 text-[#e2c678] border border-[#c9a44c]/40 animate-pulse">
                              In Progress
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#d8c2ad]/80">{step.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Kanpur Express Guarantee Box */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#23140c] via-[#1a0e08] to-[#23140c] border border-[#c9a44c]/40 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Thermometer className="w-6 h-6 text-[#c9a44c] shrink-0" />
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-[#f4ede4] block">
                    Zero-Melt Cold Gel Pack Guarantee
                  </span>
                  <span className="text-[11px] text-[#d8c2ad]/80 block">
                    Packed inside insulated thermal containers for pristine delivery in Kanpur.
                  </span>
                </div>
              </div>

              <button
                onClick={handleWhatsAppStatusInquiry}
                className="px-4 py-2.5 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors inline-flex items-center gap-2 shrink-0 cursor-pointer shadow-md"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>WhatsApp Rider Update</span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 4. Kanpur Local Delivery Coverage Information */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-[#160c07] border border-[#2d1b11] rounded-2xl p-6 sm:p-8 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
            <MapPin className="w-4 h-4 text-[#c9a44c]" />
            <span>Kanpur Delivery Localities Covered</span>
          </div>
          <h3 className="font-serif text-xl font-semibold text-[#f4ede4]">
            Same-Day Local Delivery Sectors
          </h3>
          <p className="text-xs text-[#d8c2ad] leading-relaxed">
            We provide local express delivery across all Kanpur zones including: Civil Lines, Swaroop Nagar, Tilak Nagar, Kakadeo, Kidwai Nagar, Arya Nagar, Cantt, Lajpat Nagar, Mall Road, Govind Nagar, Barra, and Shyam Nagar.
          </p>
        </div>
      </section>
    </div>
  );
};
