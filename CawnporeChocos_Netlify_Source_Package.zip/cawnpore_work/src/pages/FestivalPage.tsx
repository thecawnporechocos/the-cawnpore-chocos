import React, { useState } from 'react';
import { Sparkles, MessageCircle, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { FestivalTag, Product } from '../types/chocolate';
import { FESTIVAL_COLLECTIONS, DIWALI_IMAGE, HAMPER_IMAGE, BONBONS_IMAGE } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { getFestiveBulkEnquiryUrl, WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { createLocalOrderRecord } from '../services/orderStorage';

interface FestivalPageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  initialFestival?: FestivalTag;
}

export const FestivalPage: React.FC<FestivalPageProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  initialFestival = 'diwali',
}) => {
  const [activeTab, setActiveTab] = useState<FestivalTag>(initialFestival);

  React.useEffect(() => {
    if (initialFestival) {
      setActiveTab(initialFestival);
    }
  }, [initialFestival]);

  // Bulk Enquiry Form State
  const [contactName, setContactName] = useState('');
  const [deliveryCity, setDeliveryCity] = useState('');
  const [quantityBoxes, setQuantityBoxes] = useState('25 to 50 Hampers');
  const [requiredDate, setRequiredDate] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentCollection = FESTIVAL_COLLECTIONS.find((c) => c.id === activeTab) || FESTIVAL_COLLECTIONS[0];

  // Get products associated with this festival
  const festiveProducts = products.filter((p) => p.festivals?.includes(activeTab));

  const handleBulkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { orderId } = createLocalOrderRecord({
      customerName: contactName || 'Festive Client',
      city: deliveryCity || 'Kanpur',
      itemsSummary: `${currentCollection.title} Bulk Enquiry (${quantityBoxes})`,
      message: `Required by: ${requiredDate || 'TBD'}. Notes: ${notes || 'None'}`,
      source: `Festival Bulk: ${currentCollection.title}`,
    });

    setIsSubmitting(false);

    const message = `Namaste The Cawnpore Chocos!

*Bulk Ref:* ${orderId}

I would like to enquire about luxury chocolate gifting for *${currentCollection.title}*:

${contactName ? `*Contact Person:* ${contactName}\n` : ''}${
      deliveryCity ? `*Delivery Location:* ${deliveryCity}\n` : ''
    }${quantityBoxes ? `*Estimated Hamper Quantity:* ${quantityBoxes}\n` : ''}${
      requiredDate ? `*Required Delivery Date:* ${requiredDate}\n` : ''
    }${notes ? `*Custom Requirements:* ${notes}\n` : ''}
Please share custom curation options and corporate/wedding catalog details.`;

    window.open(buildWhatsAppUrl(message), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-16 py-12 pb-20">
      
      {/* 1. Page Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-3xl space-y-4">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
          Festive Celebrations & Milestones
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4]">
          Festival & Special Occasions
        </h1>
        <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
          From the divine glow of Deepavali diyas to Christmas warmth, playful Children's Day chocolates, and regal Indian wedding return favors. Handcrafted in Kanpur with pure cocoa butter.
        </p>

        {/* Festival Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
          {FESTIVAL_COLLECTIONS.map((fest) => {
            const isActive = activeTab === fest.id;
            return (
              <button
                key={fest.id}
                onClick={() => setActiveTab(fest.id)}
                className={`px-5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-[#c9a44c] text-[#120905] border-[#c9a44c] shadow-md font-bold'
                    : 'bg-[#1a0e08] text-[#d8c2ad] border-[#2d1b11] hover:border-[#42281b] hover:text-[#f4ede4]'
                }`}
              >
                {fest.title}
              </button>
            );
          })}
        </div>
      </section>

      {/* 2. Active Festival Spotlight Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#1a0e08] rounded-2xl border border-[#42281b] overflow-hidden grid grid-cols-1 lg:grid-cols-2">
          
          <div className="relative aspect-[4/3] lg:aspect-auto min-h-[360px] overflow-hidden">
            <img
              src={currentCollection.heroImage}
              alt={currentCollection.title}
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute top-4 left-4 bg-[#120905]/90 border border-[#c9a44c]/60 px-3 py-1 rounded text-xs text-[#e2c678] font-medium uppercase tracking-wider">
              {currentCollection.badge}
            </div>
          </div>

          <div className="p-8 sm:p-12 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
                Featured Occasion
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4] leading-tight">
                {currentCollection.title}
              </h2>
              <p className="text-xs text-[#e2c678] font-medium italic">
                {currentCollection.tagline}
              </p>
              <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
                {currentCollection.description}
              </p>

              {/* Highlights */}
              <div className="pt-2 space-y-2 text-xs text-[#d8c2ad]">
                {currentCollection.highlightFeatures.map((feat, idx) => (
                  <div key={idx} className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-[#c9a44c] shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#2d1b11] flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase text-[#d8c2ad]/60 block">Direct Order Support</span>
                <span className="text-xs text-[#e2c678] font-semibold">WhatsApp: +91 63865 90007</span>
              </div>
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                  `Namaste The Cawnpore Chocos! I would like to enquire about ordering from ${currentCollection.title}.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
              >
                Instant Enquiry
              </a>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Products Curated for this Festival */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="border-b border-[#2d1b11] pb-4 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
              Curated Selection
            </span>
            <h3 className="font-serif text-2xl font-semibold text-[#f4ede4]">
              Chocolates & Hampers for {currentCollection.title}
            </h3>
          </div>
          <span className="text-xs text-[#d8c2ad]/70">
            {festiveProducts.length} Confections
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {festiveProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

      {/* 4. Bulk Gifting & Corporate Enquiry Form */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#160c07] rounded-2xl border border-[#42281b] p-8 sm:p-12">
          <div className="max-w-2xl mx-auto text-center space-y-3 mb-8">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
              Corporate & Wedding Favors
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#f4ede4]">
              Festive Bulk Order & Corporate Concierge
            </h3>
            <p className="text-xs text-[#d8c2ad]/80">
              Planning Diwali gifts for company clients or wedding celebration hampers? Share your requirements and our Kanpur team will reply on WhatsApp with custom catalogs and volume estimates.
            </p>
          </div>

          <div className="max-w-xl mx-auto space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-[#d8c2ad]/80 mb-1">Your Name / Organization</label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="e.g. Rajesh Kumar"
                  className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                />
              </div>

              <div>
                <label className="block text-[#d8c2ad]/80 mb-1">Delivery City</label>
                <input
                  type="text"
                  value={deliveryCity}
                  onChange={(e) => setDeliveryCity(e.target.value)}
                  placeholder="e.g. Kanpur, Delhi NCR, Mumbai"
                  className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-[#d8c2ad]/80 mb-1">Estimated Boxes / Hampers</label>
                <select
                  value={quantityBoxes}
                  onChange={(e) => setQuantityBoxes(e.target.value)}
                  className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs focus:outline-none focus:border-[#c9a44c] cursor-pointer"
                >
                  <option value="10 to 25 Hampers">10 to 25 Hampers</option>
                  <option value="25 to 50 Hampers">25 to 50 Hampers</option>
                  <option value="50 to 100 Hampers">50 to 100 Hampers</option>
                  <option value="100+ Hampers (Large Bulk / Wedding)">100+ Hampers (Large Bulk / Wedding)</option>
                </select>
              </div>

              <div>
                <label className="block text-[#d8c2ad]/80 mb-1">Required Delivery Date</label>
                <input
                  type="date"
                  value={requiredDate}
                  onChange={(e) => setRequiredDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs focus:outline-none focus:border-[#c9a44c]"
                />
              </div>
            </div>

            <div className="text-xs">
              <label className="block text-[#d8c2ad]/80 mb-1">Special Preferences or Monogram Notes</label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Require gold foil company sleeve or specific vegan dark chocolate ratio"
                className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
              />
            </div>

            <button
              onClick={handleBulkSubmit}
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-semibold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors shadow-md cursor-pointer disabled:opacity-60"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>
                {isSubmitting ? 'Syncing Bulk Enquiry...' : 'Submit Bulk Enquiry to WhatsApp (+91 63865 90007)'}
              </span>
            </button>
          </div>

        </div>
      </section>

    </div>
  );
};
