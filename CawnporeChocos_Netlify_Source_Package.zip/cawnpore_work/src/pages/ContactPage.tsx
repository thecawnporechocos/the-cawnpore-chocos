import React, { useState } from 'react';
import { MessageCircle, Mail, MapPin, Send, Clock, ShieldCheck, CheckCircle2, Truck } from 'lucide-react';
import { BRAND_EMAIL, BRAND_LOCATION, DISPLAY_PHONE, WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { createLocalOrderRecord } from '../services/orderStorage';

export const ContactPage: React.FC = () => {
  const [formType, setFormType] = useState('Personal Order Enquiry');
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const directWhatsAppUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Namaste The Cawnpore Chocos! I would like to enquire about your artisanal chocolates.'
  )}`;

  const handleSendViaWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();

    // 1. Create a local order reference
    const { orderId } = createLocalOrderRecord({
      customerName: fullName || 'Enquiry Customer',
      phone: phoneNumber || 'Via WhatsApp',
      mobile: phoneNumber || 'Via WhatsApp',
      city: city || 'Kanpur',
      address,
      pincode,
      itemsSummary: formType,
      message,
      source: `Contact Page: ${formType}`,
    });

    const fullAddrString = address ? `${address}, ${city || 'Kanpur'}${pincode ? ` - ${pincode}` : ''}` : (city || 'Kanpur');

    const formattedText = `Namaste The Cawnpore Chocos!

*Enquiry Ref:* ${orderId}
*Subject:* ${formType}
*Name:* ${fullName || 'Not specified'}
*Phone / Mobile:* ${phoneNumber || 'Not specified'}
*Delivery Address:* ${fullAddrString}

*Message / Request:*
${message || 'I would like to enquire about your handcrafted chocolates and available gift hampers.'}`;

    const url = buildWhatsAppUrl(formattedText);
    setSubmitted(true);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-24 space-y-16">
      
      {/* 1. Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
          Get in Touch
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#f4ede4]">
          Contact The Cawnpore Chocos
        </h1>
        <p className="text-xs sm:text-sm text-[#d8c2ad]/80">
          We operate an artisanal micro-batch confectionery studio in Kanpur, Uttar Pradesh. Enquire directly on WhatsApp for fresh batch orders and bespoke gifting.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* 2. Left: Verified Contact Information */}
        <div className="lg:col-span-5 space-y-8">
          
          <div className="bg-[#1a0e08] rounded-2xl border border-[#42281b] p-6 sm:p-8 space-y-6">
            <h3 className="font-serif text-xl font-semibold text-[#f4ede4]">
              Verified Confectionery Details
            </h3>

            <div className="space-y-5 text-xs">
              {/* WhatsApp & Phone */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#120905] border border-[#42281b] flex items-center justify-center text-[#25D366] shrink-0">
                  <MessageCircle className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#d8c2ad]/70 block">
                    Direct WhatsApp & Phone
                  </span>
                  <a
                    href={directWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-mono font-bold text-[#e2c678] hover:text-[#f4ede4] transition-colors mt-0.5 inline-block"
                  >
                    {DISPLAY_PHONE}
                  </a>
                  <p className="text-[11px] text-[#d8c2ad]/60 mt-0.5">
                    Fastest channel for orders, gift customization, and dispatch status.
                  </p>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#120905] border border-[#42281b] flex items-center justify-center text-[#c9a44c] shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#d8c2ad]/70 block">
                    Official Email
                  </span>
                  <a
                    href={`mailto:${BRAND_EMAIL}`}
                    className="text-sm font-semibold text-[#f4ede4] hover:text-[#e2c678] transition-colors mt-0.5 inline-block"
                  >
                    {BRAND_EMAIL}
                  </a>
                  <p className="text-[11px] text-[#d8c2ad]/60 mt-0.5">
                    For corporate gifting proposals and formal inquiries.
                  </p>
                </div>
              </div>

              {/* Location */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#120905] border border-[#42281b] flex items-center justify-center text-[#c9a44c] shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#d8c2ad]/70 block">
                    Location & Confectionery Studio
                  </span>
                  <span className="text-sm font-semibold text-[#f4ede4] mt-0.5 block">
                    {BRAND_LOCATION}
                  </span>
                  <p className="text-[11px] text-[#d8c2ad]/60 mt-0.5">
                    All confections freshly produced and dispatched directly from Kanpur.
                  </p>
                </div>
              </div>

              {/* Schedule */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#120905] border border-[#42281b] flex items-center justify-center text-[#c9a44c] shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#d8c2ad]/70 block">
                    WhatsApp Enquiry Hours
                  </span>
                  <span className="text-xs font-semibold text-[#f4ede4] mt-0.5 block">
                    Monday to Sunday: 9:00 AM – 9:00 PM IST
                  </span>
                  <p className="text-[11px] text-[#d8c2ad]/60 mt-0.5">
                    Messages received after hours will be attended to first thing the next morning.
                  </p>
                </div>
              </div>
            </div>

            {/* Direct Instant Button */}
            <div className="pt-2">
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Start WhatsApp Chat Now</span>
              </a>
            </div>

          </div>

          <div className="bg-[#120905] rounded-xl border border-[#2d1b11] p-5 text-xs text-[#d8c2ad] space-y-2">
            <h4 className="font-serif text-sm font-semibold text-[#e2c678]">Dispatch Note</h4>
            <p className="text-[11px] leading-relaxed text-[#d8c2ad]/80">
              Chocolates are packed in temperature-insulated food-grade boxes to ensure complete safety and shape integrity throughout transit.
            </p>
          </div>

        </div>

        {/* 3. Right: Interactive WhatsApp Enquiry Form */}
        <div className="lg:col-span-7">
          <div className="bg-[#1a0e08] rounded-2xl border border-[#42281b] p-6 sm:p-10 shadow-xl">
            <div className="mb-6">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block mb-1">
                Order & Inquiry Form
              </span>
              <h3 className="font-serif text-2xl font-semibold text-[#f4ede4]">
                Send an Enquiry Directly to WhatsApp
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                Fill in your details below and click submit to instantly open your enquiry on WhatsApp (+91 63865 90007).
              </p>
            </div>

            {submitted && (
              <div className="mb-6 p-4 bg-emerald-950/60 border border-emerald-600/40 rounded-xl flex items-center gap-3 text-emerald-300 text-xs">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>Enquiry opened in WhatsApp. You can also message directly anytime on +91 63865 90007.</span>
              </div>
            )}

            <form onSubmit={handleSendViaWhatsApp} className="space-y-4 text-xs">
              
              <div>
                <label className="block text-[#d8c2ad]/80 mb-1 font-medium">
                  Nature of Enquiry
                </label>
                <select
                  value={formType}
                  onChange={(e) => setFormType(e.target.value)}
                  className="w-full bg-[#120905] border border-[#42281b] rounded-lg p-2.5 text-xs text-[#f4ede4] focus:outline-none focus:border-[#c9a44c] cursor-pointer"
                >
                  <option value="Personal Chocolate Order">Personal Chocolate Order</option>
                  <option value="Diwali / Festive Gift Hampers">Diwali / Festive Gift Hampers</option>
                  <option value="Christmas Holiday Confections">Christmas Holiday Confections</option>
                  <option value="Wedding Trousseau & Return Favors">Wedding Trousseau & Return Favors</option>
                  <option value="Corporate Bulk Gifting (25+ Boxes)">Corporate Bulk Gifting (25+ Boxes)</option>
                  <option value="Bespoke Flavor / Custom Box Request">Bespoke Flavor / Custom Box Request</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1 font-medium">Your Full Name</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Ananya Verma"
                    className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>

                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1 font-medium">Contact Phone Number</label>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-[#d8c2ad]/80 mb-1 font-medium">City / Delivery Destination *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Kanpur, Lucknow, Delhi"
                    className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
                <div>
                  <label className="block text-[#d8c2ad]/80 mb-1 font-medium">PIN Code *</label>
                  <input
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    placeholder="e.g. 208001"
                    className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#d8c2ad]/80 mb-1 font-medium">Full Delivery Address (Optional)</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House/Flat No., Road/Sector, Landmark"
                  className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                />
              </div>

              <div>
                <label className="block text-[#d8c2ad]/80 mb-1 font-medium">
                  Message / Quantity / Flavour Preferences
                </label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe the items you are interested in, preferred quantity of hampers, or specific dates for celebration dispatch..."
                  className="w-full px-3 py-2.5 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 px-4 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-bold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Send Enquiry to WhatsApp (+91 63865 90007)</span>
                </button>
              </div>

              <p className="text-[10px] text-center text-[#d8c2ad]/60 pt-1">
                Your message is sent directly to the official confectioner WhatsApp for The Cawnpore Chocos.
              </p>

            </form>

          </div>
        </div>

      </div>

      {/* 4. Dedicated Delivery Status & Kanpur Local Delivery Section */}
      <section className="bg-[#1a0e08] rounded-2xl border border-[#42281b] overflow-hidden shadow-xl">
        <div className="p-6 sm:p-10 border-b border-[#2d1b11] bg-gradient-to-r from-[#23140c] via-[#1a0e08] to-[#23140c]">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#e2c678] mb-2">
              <Truck className="w-4 h-4 text-[#c9a44c]" />
              <span>Kanpur Express & Local Delivery</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-4xl font-semibold text-[#f4ede4]">
              Local Delivery Process & Order Timeline
            </h2>
            <p className="text-xs sm:text-sm text-[#d8c2ad] mt-2 leading-relaxed">
              We handcraft every chocolate with 100% pure cocoa butter in our Kanpur studio. To protect delicate cocoa temper, all local Kanpur orders are dispatched in specialized insulated containers.
            </p>
          </div>
        </div>

        <div className="p-6 sm:p-10 space-y-10">
          
          {/* Process Steps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Step 1 */}
            <div className="bg-[#120905] p-5 rounded-xl border border-[#2d1b11] space-y-3">
              <div className="w-10 h-10 rounded-full bg-[#1a0e08] border border-[#42281b] flex items-center justify-center text-[#e2c678] font-mono font-bold text-sm">
                01
              </div>
              <h3 className="font-serif text-base font-semibold text-[#f4ede4]">
                Fresh Small-Batch Tempering
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Upon WhatsApp order confirmation, your chocolates, bonbons, or gift hampers are freshly assembled and prepared to order.
              </p>
              <div className="text-[11px] text-[#c9a44c]">
                Timeline: 2 to 6 hours
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-[#120905] p-5 rounded-xl border border-[#2d1b11] space-y-3">
              <div className="w-10 h-10 rounded-full bg-[#1a0e08] border border-[#42281b] flex items-center justify-center text-[#e2c678] font-mono font-bold text-sm">
                02
              </div>
              <h3 className="font-serif text-base font-semibold text-[#f4ede4]">
                Insulated Thermal Packaging
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Packed in rigid keepsake gift boxes with food-grade moisture shields and reusable cold gel packs to withstand ambient weather.
              </p>
              <div className="text-[11px] text-[#c9a44c]">
                Zero melt guarantee
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-[#120905] p-5 rounded-xl border border-[#2d1b11] space-y-3">
              <div className="w-10 h-10 rounded-full bg-[#1a0e08] border border-[#42281b] flex items-center justify-center text-[#e2c678] font-mono font-bold text-sm">
                03
              </div>
              <h3 className="font-serif text-base font-semibold text-[#f4ede4]">
                Doorstep Delivery across Kanpur
              </h3>
              <p className="text-xs text-[#d8c2ad]/80 leading-relaxed">
                Delivered straight to your residence or event venue via direct local delivery partners. Same-day available for early orders.
              </p>
              <div className="text-[11px] text-[#c9a44c]">
                Same-Day / Next-Day dispatch
              </div>
            </div>

          </div>

          {/* Kanpur Coverage Areas Banner */}
          <div className="p-5 rounded-xl bg-[#120905] border border-[#2d1b11] flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
            <div>
              <span className="font-semibold text-[#e2c678] uppercase tracking-wider block text-[11px] mb-1">
                Kanpur Locality Coverage
              </span>
              <p className="text-[#d8c2ad]/90">
                Civil Lines · Swaroop Nagar · Tilak Nagar · Kakadeo · Kidwai Nagar · Cantonment (Cantt) · Arya Nagar · Govind Nagar · Mall Road · Lajpat Nagar · Shastri Nagar · Barra & all Kanpur sectors.
              </p>
            </div>
            <div className="shrink-0 bg-[#1a0e08] px-3.5 py-2 rounded-lg border border-[#42281b] text-center">
              <span className="text-[#e2c678] font-mono font-bold text-sm block">Same-Day</span>
              <span className="text-[10px] text-[#d8c2ad]/70">Available across Kanpur</span>
            </div>
          </div>

          {/* Interactive Check Order Timeline via WhatsApp Form */}
          <div className="bg-[#160c07] rounded-xl border border-[#c9a44c]/40 p-6 sm:p-8">
            <div className="max-w-xl mx-auto text-center space-y-2 mb-6">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#e2c678] block">
                Order Tracking & Timeline
              </span>
              <h3 className="font-serif text-2xl font-semibold text-[#f4ede4]">
                Check Your Order Timeline via WhatsApp
              </h3>
              <p className="text-xs text-[#d8c2ad]/80">
                Already placed an order? Enter your name or delivery locality to request an instant status update directly from our Kanpur dispatch team.
              </p>
            </div>

            <OrderTimelineChecker />
          </div>

        </div>
      </section>

    </div>
  );
};

// Child Component for checking order timeline via WhatsApp
const OrderTimelineChecker: React.FC = () => {
  const [orderIdentifier, setOrderIdentifier] = useState('');
  const [locality, setLocality] = useState('Civil Lines');
  const [targetDate, setTargetDate] = useState('');
  const [customLocality, setCustomLocality] = useState('');

  const effectiveLocality = locality === 'Other Kanpur Area' ? (customLocality || 'Kanpur') : locality;

  const handleCheckStatus = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Namaste The Cawnpore Chocos!

I would like to check the *Delivery Status & Timeline* for my chocolate order:

*Customer Name / Order Ref:* ${orderIdentifier || 'Recent Order'}
*Delivery Locality in Kanpur:* ${effectiveLocality}
${targetDate ? `*Order / Required Delivery Date:* ${targetDate}\n` : ''}
Kindly share the current dispatch status, packing stage, and estimated delivery timeline. Thank you!`;

    const url = buildWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <form onSubmit={handleCheckStatus} className="max-w-xl mx-auto space-y-4 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-[#d8c2ad]/80 mb-1 font-medium">
            Your Name / Order Reference
          </label>
          <input
            type="text"
            required
            value={orderIdentifier}
            onChange={(e) => setOrderIdentifier(e.target.value)}
            placeholder="e.g. Ananya / Festive Hamper"
            className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
          />
        </div>

        <div>
          <label className="block text-[#d8c2ad]/80 mb-1 font-medium">
            Kanpur Delivery Locality
          </label>
          <select
            value={locality}
            onChange={(e) => setLocality(e.target.value)}
            className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs focus:outline-none focus:border-[#c9a44c] cursor-pointer"
          >
            <option value="Civil Lines">Civil Lines</option>
            <option value="Swaroop Nagar">Swaroop Nagar</option>
            <option value="Tilak Nagar">Tilak Nagar</option>
            <option value="Kakadeo">Kakadeo</option>
            <option value="Kidwai Nagar">Kidwai Nagar</option>
            <option value="Cantonment (Cantt)">Cantonment (Cantt)</option>
            <option value="Arya Nagar">Arya Nagar</option>
            <option value="Govind Nagar">Govind Nagar</option>
            <option value="Mall Road / Phool Bagh">Mall Road / Phool Bagh</option>
            <option value="Lajpat Nagar">Lajpat Nagar</option>
            <option value="Other Kanpur Area">Other Kanpur Area</option>
          </select>
        </div>
      </div>

      {locality === 'Other Kanpur Area' && (
        <div>
          <label className="block text-[#d8c2ad]/80 mb-1 font-medium">Specify Kanpur Area / Landmark</label>
          <input
            type="text"
            required
            value={customLocality}
            onChange={(e) => setCustomLocality(e.target.value)}
            placeholder="e.g. Shyam Nagar, Panki, Rawatpur"
            className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
          />
        </div>
      )}

      <div>
        <label className="block text-[#d8c2ad]/80 mb-1 font-medium">
          Order Date or Expected Delivery Date (Optional)
        </label>
        <input
          type="date"
          value={targetDate}
          onChange={(e) => setTargetDate(e.target.value)}
          className="w-full px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] text-xs focus:outline-none focus:border-[#c9a44c]"
        />
      </div>

      <div className="pt-2">
        <button
          type="submit"
          className="w-full py-3 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-bold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg cursor-pointer"
        >
          <MessageCircle className="w-4 h-4 fill-current" />
          <span>Check Delivery Timeline on WhatsApp (+91 63865 90007)</span>
        </button>
      </div>

      <p className="text-[10px] text-center text-[#d8c2ad]/60">
        Directly connects with the local Kanpur delivery desk for immediate live coordination.
      </p>
    </form>
  );
};
