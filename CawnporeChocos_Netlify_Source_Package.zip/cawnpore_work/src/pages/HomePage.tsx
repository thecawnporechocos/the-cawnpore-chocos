import React from 'react';
import { ArrowRight, MessageCircle, Sparkles, Gift, ShieldCheck, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { Product } from '../types/chocolate';
import {
  BRAND_LOGO,
  DIWALI_REAL_BOX_IMAGE,
  ROYAL_HAMPER_IMAGE,
  ROKA_CEREMONY_TRAY,
  BIRTHDAY_BONBONS,
  CELEBRATION_BOXES_IMAGE,
  CHRISTMAS_TRUFFLES,
  CHILDRENS_CLUSTERS,
} from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { CustomerExperiencesCarousel } from '../components/CustomerExperiencesCarousel';
import { WHATSAPP_NUMBER } from '../utils/whatsapp';

interface HomePageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onNavigate: (page: string, filter?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  onNavigate,
}) => {
  const heroWhatsAppUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Namaste The Cawnpore Chocos! I would like to enquire about ordering your luxury chocolates.'
  )}`;

  const occasionShowcase = [
    { id: 'diwali', name: 'Diwali Celebrations', image: DIWALI_REAL_BOX_IMAGE },
    { id: 'weddings', name: 'Royal Weddings', image: ROYAL_HAMPER_IMAGE },
    { id: 'roka', name: 'Roka & Sagan', image: ROKA_CEREMONY_TRAY },
    { id: 'birthday', name: 'Birthday Celebrations', image: BIRTHDAY_BONBONS },
  ];

  return (
    <div className="space-y-16 pb-16">
      {/* 1. Hero Section */}
      <motion.section 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative h-[70vh] flex items-center justify-center bg-[#1a100a] text-white overflow-hidden"
      >
        <div className="relative z-10 text-center space-y-6 px-4">
          <h1 className="text-5xl md:text-7xl font-serif">The Cawnpore Chocos</h1>
          <p className="text-xl md:text-2xl text-gray-300">Handcrafted Luxury Chocolates</p>
          <a
            href={heroWhatsAppUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-full transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Order on WhatsApp
          </a>
        </div>
      </motion.section>

      {/* 2. About/Brand Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto px-4 text-center space-y-6"
      >
        <h2 className="text-3xl font-serif">Our Story</h2>
        <p className="text-lg text-gray-600">
          At The Cawnpore Chocos, we blend traditional craftsmanship with modern luxury. Every chocolate is a masterpiece, made with the finest ingredients to bring joy to your celebrations.
        </p>
      </motion.section>

      {/* 3. Hampers/Occasions */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-4"
      >
        <h2 className="text-3xl font-serif mb-8 text-center">Seasonal Hampers</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {occasionShowcase.map((occasion) => (
            <div key={occasion.id} className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
              <img src={occasion.image} alt={occasion.name} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h3 className="text-lg font-semibold">{occasion.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </motion.section>

      {/* 4. Product Listing */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-4"
      >
        <h2 className="text-3xl font-serif mb-8 text-center">Our Chocolates</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </motion.section>

      {/* 5. Reviews */}
      <CustomerExperiencesCarousel />
    </div>
  );
};
