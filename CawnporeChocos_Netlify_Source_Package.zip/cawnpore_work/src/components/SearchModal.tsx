import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Product } from '../types/chocolate';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filtered = query.trim() === ''
    ? []
    : products.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.subtitle.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tastingNotes.some((n) => n.toLowerCase().includes(q)) ||
          p.ingredients.toLowerCase().includes(q)
        );
      });

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 px-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-[#1a0e08] rounded-xl border border-[#42281b] overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="p-4 border-b border-[#2d1b11] flex items-center gap-3 bg-[#120905]">
          <Search className="w-5 h-5 text-[#c9a44c] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by cocoa %, saffron, bonbons, truffles, nuts..."
            className="w-full bg-transparent text-[#f4ede4] placeholder-[#d8c2ad]/40 text-sm focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs uppercase tracking-wider text-[#d8c2ad] hover:text-[#f4ede4] px-2 py-1 rounded hover:bg-[#2d1b11] cursor-pointer"
          >
            Esc
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-96 overflow-y-auto p-4">
          {query.trim() === '' ? (
            <div className="py-6 text-center text-xs text-[#d8c2ad]/70 space-y-2">
              <p>Type keywords like "truffles", "pistachio", "74%", "Diwali", or "hampers"</p>
              <div className="flex flex-wrap justify-center gap-2 pt-2">
                {['Gold Truffles', 'Saffron', 'Hampers', '82% Noir', 'Bonbons'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-2.5 py-1 text-xs rounded bg-[#23140c] text-[#e2c678] hover:bg-[#2d1b11] border border-[#42281b] cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#d8c2ad]/70">
              No handcrafted confections matching "{query}". Try searching for cocoa %, gift hampers, or nuts.
            </div>
          ) : (
            <div className="space-y-2">
              {filtered.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectProduct(item);
                    onClose();
                  }}
                  className="flex items-center gap-3.5 p-2.5 rounded-lg hover:bg-[#23140c] cursor-pointer transition-colors border border-transparent hover:border-[#42281b]"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-12 h-12 rounded object-cover bg-[#120905] shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-serif text-sm font-semibold text-[#f4ede4] truncate">
                      {item.name}
                    </h5>
                    <p className="text-[11px] text-[#d8c2ad]/70 truncate">
                      {item.cocoaPercentage}% Cocoa · {item.weight}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono tabular-nums text-xs font-bold text-[#e2c678]">
                      ₹{item.price.toLocaleString('en-IN')}
                    </span>
                    <ArrowRight className="w-4 h-4 text-[#d8c2ad]/60 ml-auto mt-1" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
