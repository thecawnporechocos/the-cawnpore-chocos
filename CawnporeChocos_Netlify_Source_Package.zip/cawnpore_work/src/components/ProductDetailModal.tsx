import React, { useState } from 'react';
import { X, MessageCircle, ShoppingBag, Plus, Minus, ShieldCheck, Sparkles, Check } from 'lucide-react';
import { Product } from '../types/chocolate';
import { getProductOrderWhatsAppUrl, WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { createLocalOrderRecord } from '../services/orderStorage';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, customNote?: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [customNote, setCustomNote] = useState('');
  const [added, setAdded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const totalPrice = product.price * quantity;

  const handleDirectWhatsAppOrder = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { orderId } = createLocalOrderRecord({
      customerName: 'Direct Customer',
      itemsSummary: `${product.name} (${product.weight}) × ${quantity}`,
      totalAmount: totalPrice,
      customNote,
      source: 'Direct Product Modal',
    });

    setIsSubmitting(false);

    const directMessage = `Namaste The Cawnpore Chocos!

*Order Reference:* ${orderId}

I would like to order:
*Item:* ${product.name}
*Specification:* ${product.weight} · ${product.cocoaPercentage}% Cocoa
*Quantity:* ${quantity}
*Total Value:* ₹${totalPrice.toLocaleString('en-IN')}
${customNote ? `*Special Request:* ${customNote}\n` : ''}
Kindly let me know the batch availability, packaging, and dispatch timeline. Thank you!`;

    window.open(buildWhatsAppUrl(directMessage), '_blank', 'noopener,noreferrer');
  };

  const handleAdd = () => {
    onAddToCart(product, quantity, customNote);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
    }, 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#1a0e08] rounded-2xl border border-[#42281b] overflow-hidden shadow-2xl my-8 animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-[#120905]/80 text-[#d8c2ad] hover:text-[#f4ede4] hover:bg-[#2d1b11] transition-colors cursor-pointer border border-[#42281b]"
          aria-label="Close details"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Product Media Gallery */}
          <div className="relative bg-[#120905] aspect-square md:aspect-auto md:h-full min-h-[340px] flex items-center justify-center overflow-hidden">
            {!imageError ? (
              <img
                src={product.image}
                alt={product.name}
                referrerPolicy="no-referrer"
                onError={() => setImageError(true)}
                className="w-full h-full object-cover object-center"
              />
            ) : (
              <div className="p-8 text-center">
                <span className="font-serif text-2xl text-[#e2c678] block">{product.name}</span>
                <span className="text-xs text-[#d8c2ad]/70 mt-2 block">Handcrafted in Kanpur, UP</span>
              </div>
            )}
            
            <div className="absolute bottom-4 left-4 right-4 bg-[#120905]/85 backdrop-blur-md border border-[#42281b] p-3 rounded-lg text-xs flex items-center justify-between">
              <span className="text-[#e2c678] font-semibold">{product.cocoaPercentage}% Pure Cocoa</span>
              <span className="text-[#d8c2ad]">{product.weight}</span>
              <span className="text-[#c9a44c]">Pure Vegetarian</span>
            </div>
          </div>

          {/* Right: Product Story & Contiguous Purchase Module */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Quiet provenance header */}
              <div className="flex items-center gap-2 text-xs text-[#c9a44c] tracking-wider uppercase mb-2">
                <span>The Cawnpore Chocos</span>
                <span aria-hidden="true">·</span>
                <span>Kanpur Favourite Chocolate Gift Brand</span>
              </div>

              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#f4ede4] leading-tight">
                {product.name}
              </h2>

              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                {product.subtitle}
              </p>

              {/* Price Row */}
              <div className="mt-4 pb-4 border-b border-[#2d1b11] flex items-baseline gap-3">
                <span className="font-mono tabular-nums text-2xl sm:text-3xl font-bold text-[#e2c678]">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-[#d8c2ad]/70">
                  Per pack ({product.weight})
                </span>
              </div>

              {/* Description */}
              <div className="py-4 space-y-3">
                <p className="text-xs text-[#d8c2ad] leading-relaxed">
                  {product.description}
                </p>

                {/* Tasting Notes */}
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#e2c678] block mb-1.5">
                    Flavor Notes
                  </span>
                  <div className="flex flex-wrap gap-2 text-xs">
                    {product.tastingNotes.map((note, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded bg-[#23140c] border border-[#42281b] text-[#f4ede4]"
                      >
                        {note}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Specifications List */}
                <div className="bg-[#120905]/70 rounded-lg p-3 border border-[#2d1b11] space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#d8c2ad]/70">Ingredients</span>
                    <span className="text-[#f4ede4] text-right max-w-[65%]">{product.ingredients}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d8c2ad]/70">Dietary</span>
                    <span className="text-[#e2c678] font-medium">{product.dietary}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d8c2ad]/70">Shelf Life</span>
                    <span className="text-[#f4ede4]">{product.shelfLife}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d8c2ad]/70">Origin</span>
                    <span className="text-[#f4ede4]">Handcrafted in Kanpur, UP, India</span>
                  </div>
                </div>

                {/* Chocolate Care & Freshness Section */}
                <div className="bg-[#1a0e08] rounded-xl p-4 border border-[#c9a44c]/30 space-y-2">
                  <h4 className="font-serif text-sm font-semibold text-[#e2c678] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#c9a44c]" />
                    <span>Chocolate Care & Freshness Instructions</span>
                  </h4>
                  <ul className="space-y-1.5 text-[11px] text-[#d8c2ad]">
                    <li className="flex items-start gap-2">
                      <span className="text-[#c9a44c] font-bold">•</span>
                      <span><strong>Storage:</strong> Store in a cool, dry place between 16°C and 20°C away from direct sunlight and strong kitchen aromas.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#c9a44c] font-bold">•</span>
                      <span><strong>Warm Weather:</strong> If ambient room temperature exceeds 24°C, refrigerate inside an airtight container to preserve pure cocoa butter temper.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#c9a44c] font-bold">•</span>
                      <span><strong>Serving:</strong> Rest chilled chocolates at room temperature for 15–20 minutes before savoring to release full flavor aromas.</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Quantity Selector & Custom Note */}
              <div className="pt-2 pb-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#f4ede4]">Quantity</span>
                  <div className="flex items-center gap-3 bg-[#120905] border border-[#42281b] rounded-lg p-1">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-1 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="font-mono tabular-nums text-sm font-bold text-[#e2c678] px-2 min-w-[24px] text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="p-1 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <label htmlFor="custom-note" className="block text-[11px] text-[#d8c2ad]/80 mb-1">
                    Custom Gifting Note or Request (Optional)
                  </label>
                  <input
                    id="custom-note"
                    type="text"
                    value={customNote}
                    onChange={(e) => setCustomNote(e.target.value)}
                    placeholder="e.g. Include gold ribbon & Diwali greeting"
                    className="w-full text-xs px-3 py-2 bg-[#120905] border border-[#42281b] rounded-lg text-[#f4ede4] placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>
            </div>

            {/* Contiguous Purchase Action Buttons */}
            <div className="pt-4 border-t border-[#2d1b11] space-y-2.5">
              <div className="flex items-center justify-between text-xs text-[#d8c2ad] mb-1">
                <span>Total Value ({quantity} {quantity === 1 ? 'pack' : 'packs'}):</span>
                <span className="font-mono tabular-nums text-lg font-bold text-[#e2c678]">
                  ₹{totalPrice.toLocaleString('en-IN')}
                </span>
              </div>

              {/* Primary High-Intent Action: WhatsApp Order Button with Local Order Reference */}
              <button
                onClick={handleDirectWhatsAppOrder}
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-semibold text-sm rounded-lg flex items-center justify-center gap-2.5 transition-all shadow-md hover:shadow-lg cursor-pointer disabled:opacity-60"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>
                  {isSubmitting ? 'Preparing WhatsApp...' : 'Order Now on WhatsApp (+91 63865 90007)'}
                </span>
              </button>

              {/* Secondary Action: Add to Enquiry Bag */}
              <button
                onClick={handleAdd}
                className={`w-full py-2.5 px-4 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  added
                    ? 'bg-emerald-950 border-emerald-600 text-emerald-400'
                    : 'bg-[#23140c] border-[#42281b] text-[#f4ede4] hover:border-[#c9a44c]'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Enquiry Bag</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-[#e2c678]" />
                    <span>Add to Multi-Item Enquiry Bag</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
