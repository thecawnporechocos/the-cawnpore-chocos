import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Quote, Sparkles, Heart } from 'lucide-react';

export interface CustomerExperience {
  id: string;
  name: string;
  location: string;
  occasion: string;
  rating: number;
  date: string;
  quote: string;
  highlight: string;
}

export const CUSTOMER_EXPERIENCES: CustomerExperience[] = [
  {
    id: 'exp-1',
    name: 'Ananya & Vikram Singhania',
    location: 'Civil Lines, Kanpur',
    occasion: 'Wedding Return Favors & Trousseau Trunks',
    rating: 5,
    date: 'February 2026',
    highlight: 'Pure Cocoa Butter & Royal Monogrammed Boxes',
    quote:
      'We wanted bespoke confectionery favors for our daughter’s wedding in Kanpur. The Awadh Wedding Trousseau Trunks with gold foil monograms and saffron pistachio medallions mesmerized our guests. The melt of pure cocoa butter and absence of palm oil made an immediate difference.',
  },
  {
    id: 'exp-2',
    name: 'Dr. Pradeep Mehrotra',
    location: 'Swaroop Nagar, Kanpur',
    occasion: 'Diwali Festive Family Gifting',
    rating: 5,
    date: 'Diwali Edition',
    highlight: '24K Gold Dusted Truffles & Mamra Almond Rochers',
    quote:
      'Replacing traditional syrup sweets with The Cawnpore Chocos has become our family tradition every Diwali. The 24K gold-dusted dark truffles and roasted Mamra almond rochers are incomparably fresh, sophisticated, and made with true artisanal reverence.',
  },
  {
    id: 'exp-3',
    name: 'Megha Agarwal',
    location: 'Tilak Nagar, Kanpur',
    occasion: '25th Wedding Anniversary Milestone',
    rating: 5,
    date: 'Silver Jubilee',
    highlight: 'Hand-Painted Jewel Bonbons & Custom Parchment Note',
    quote:
      'Ordered a custom 24-piece box featuring their single-estate dark slabs and jewel bonbons. The hand-painted cacao butter designs and customized gold ribbon made our anniversary dinner truly memorable. The doorstep delivery in Kanpur was prompt and perfectly chilled.',
  },
  {
    id: 'exp-4',
    name: 'Siddharth Kapoor',
    location: 'Mall Road, Kanpur',
    occasion: 'Corporate Festive Gifting (60+ Hampers)',
    rating: 5,
    date: 'Corporate Concierge',
    highlight: 'Immaculate Insulated Transit & Client Appreciation',
    quote:
      'Sent over 60 bespoke festive boxes to our corporate partners across Uttar Pradesh and Delhi NCR. The insulated packaging arrived in pristine condition with zero melting, and the feedback from our executive clients on the taste was extraordinary.',
  },
  {
    id: 'exp-5',
    name: 'Pooja & Rohan Bajpai',
    location: 'Kidwai Nagar, Kanpur',
    occasion: 'Children’s Day & Birthday Confections',
    rating: 5,
    date: 'Family Milestone',
    highlight: 'Gentle Milk Honeycomb Bites without Palm Oil',
    quote:
      'Our children loved the creamy milk honeycomb drops and crunchy nut clusters. As parents, knowing that every chocolate is handcrafted with 100% pure cocoa butter and zero hydrogenated vegetable fats gave us complete peace of mind.',
  },
];

export const CustomerExperiencesCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const total = CUSTOMER_EXPERIENCES.length;

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % total);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + total) % total);
  };

  // Auto-play interval
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % total);
    }, 5500);
    return () => clearInterval(interval);
  }, [isPaused, total]);

  const current = CUSTOMER_EXPERIENCES[currentIndex];

  return (
    <section
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="bg-[#1a0e08] rounded-2xl border border-[#42281b] overflow-hidden p-6 sm:p-12 shadow-2xl relative">
        
        {/* Subtle Background Ornament */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-[#c9a44c]/10 via-transparent to-transparent pointer-events-none" />

        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-[#2d1b11]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#e2c678] mb-2">
              <Heart className="w-3.5 h-3.5 text-[#c9a44c] fill-current" />
              <span>Client Voices</span>
              <span aria-hidden="true" className="text-[#5c3927]">·</span>
              <span>Kanpur & Beyond</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4]">
              Customer Experiences
            </h2>
            <p className="text-xs sm:text-sm text-[#d8c2ad]/80 mt-1">
              Reflections from families, connoisseurs, and wedding celebrations who trust The Cawnpore Chocos.
            </p>
          </div>

          {/* Carousel Arrow Controls */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="font-mono text-xs text-[#d8c2ad]/70 tabular-nums">
              0{currentIndex + 1} / 0{total}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={prevSlide}
                className="p-2.5 rounded-lg bg-[#120905] border border-[#42281b] text-[#d8c2ad] hover:text-[#f4ede4] hover:border-[#c9a44c] transition-colors cursor-pointer"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextSlide}
                className="p-2.5 rounded-lg bg-[#120905] border border-[#42281b] text-[#d8c2ad] hover:text-[#f4ede4] hover:border-[#c9a44c] transition-colors cursor-pointer"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Testimonial Active Display */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column: Quote Content */}
          <div className="lg:col-span-8 space-y-6">
            <Quote className="w-10 h-10 text-[#c9a44c]/40 rotate-180" />

            <blockquote className="font-serif text-xl sm:text-2xl text-[#f4ede4] leading-relaxed italic">
              "{current.quote}"
            </blockquote>

            <div className="space-y-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] block">
                {current.highlight}
              </span>
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#d8c2ad]">
                <strong className="text-[#f4ede4] font-medium">{current.name}</strong>
                <span aria-hidden="true" className="text-[#c9a44c]">·</span>
                <span>{current.location}</span>
                <span aria-hidden="true" className="text-[#c9a44c]">·</span>
                <span className="text-[#e2c678] font-normal">{current.occasion}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Occasion Milestone Card */}
          <div className="lg:col-span-4 bg-[#120905] rounded-xl border border-[#2d1b11] p-6 space-y-4">
            <span className="text-[10px] uppercase tracking-wider text-[#d8c2ad]/60 block font-semibold">
              Celebration Milestone
            </span>
            <h3 className="font-serif text-lg font-semibold text-[#f4ede4]">
              {current.occasion}
            </h3>
            <div className="space-y-2 text-xs text-[#d8c2ad]/80">
              <div className="flex justify-between border-b border-[#2d1b11] pb-1.5">
                <span className="text-[#d8c2ad]/60">Client</span>
                <span className="text-[#f4ede4] font-medium text-right">{current.name}</span>
              </div>
              <div className="flex justify-between border-b border-[#2d1b11] pb-1.5">
                <span className="text-[#d8c2ad]/60">City</span>
                <span className="text-[#e2c678] font-medium">{current.location}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#d8c2ad]/60">Quality Note</span>
                <span className="text-[#f4ede4]">100% Pure Cocoa Butter</span>
              </div>
            </div>
            <div className="pt-2">
              <span className="text-[11px] text-[#c9a44c] flex items-center gap-1.5 font-medium">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Verified Handcrafted Order</span>
              </span>
            </div>
          </div>

        </div>

        {/* Carousel Dots Navigation */}
        <div className="mt-8 pt-6 border-t border-[#2d1b11] flex items-center justify-between">
          <div className="flex items-center gap-2">
            {CUSTOMER_EXPERIENCES.map((exp, idx) => (
              <button
                key={exp.id}
                onClick={() => setCurrentIndex(idx)}
                className={`transition-all duration-300 rounded-full cursor-pointer ${
                  currentIndex === idx
                    ? 'w-8 h-2 bg-[#c9a44c]'
                    : 'w-2 h-2 bg-[#42281b] hover:bg-[#c9a44c]/60'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          <div className="text-[11px] text-[#d8c2ad]/60 hidden sm:block">
            <span>Hover to pause auto-slide</span>
          </div>
        </div>

      </div>
    </section>
  );
};
