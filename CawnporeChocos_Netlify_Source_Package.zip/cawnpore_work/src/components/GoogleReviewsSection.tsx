import React, { useState } from 'react';
import { Star, CheckCircle, MessageCircle, ChevronDown, ChevronUp, MapPin, Filter } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../utils/whatsapp';

export interface GoogleReview {
  id: string;
  author: string;
  location: string;
  city: string;
  isLocalGuide?: boolean;
  reviewCount?: number;
  timeAgo: string;
  rating: 5 | 4;
  category: 'all' | 'kanpur' | 'up_ncr' | 'hampers' | 'kunafa_biscoff' | 'delivery';
  lang: 'hi' | 'en';
  serviceUsed: string;
  comment: string;
}

export const GOOGLE_REVIEWS: GoogleReview[] = [
  // --- Kanpur Localities (Reviews 1 to 25) ---
  {
    id: 'gr-1',
    author: 'अंशुल गुप्ता (Anshul Gupta)',
    location: 'स्वरूप नगर, कानपुर (Swaroop Nagar, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '1 week ago',
    rating: 5,
    category: 'kunafa_biscoff',
    lang: 'hi',
    serviceUsed: 'Kunafa & 24K Gold Chocolates',
    comment:
      'कानपुर की सबसे बेस्ट होममेड चॉकलेट्स! हमने अपनी बेटी के रोका सेरेमनी के लिए कुनाफा चॉकलेट्स और 24K गोल्ड ट्रफल्स ऑर्डर किए थे। पैकिंग इतनी रॉयल थी कि सारे रिश्तेदार पूछ रहे थे। 100% शुद्ध कोको बटर और पूरी तरह से वेज (eggless)!',
  },
  {
    id: 'gr-2',
    author: 'रचना अग्रवाल (Rachna Agarwal)',
    location: 'सिविल लाइंस, कानपुर (Civil Lines, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '2 weeks ago',
    rating: 5,
    category: 'hampers',
    lang: 'hi',
    serviceUsed: 'Subh Deepavali Shahi Box (₹1,850)',
    comment:
      'दीपावली गिफ्टिंग के लिए हमने शुभ दीपावली शाही बॉक्स लिया था। केसर पिस्ता मेडेलियन और ड्राई फ्रूट रोचर्स का स्वाद लाजवाब था। कानपुर में ऐसी प्रीमियम चॉकलेट मिलना गर्व की बात है।',
  },
  {
    id: 'gr-3',
    author: 'Gaurav Tandon',
    location: 'Civil Lines, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '2 weeks ago',
    rating: 5,
    category: 'hampers',
    lang: 'en',
    serviceUsed: 'Royal Heritage Hamper (₹2,450)',
    comment:
      'Ordered 15 Royal Heritage hampers for Diwali corporate gifting in Kanpur. The packaging with gold lettering and satin ribbons was top-notch, and the chocolates inside were unbelievable. Pure cocoa butter melts so smoothly!',
  },
  {
    id: 'gr-4',
    author: 'विकास अवस्थी (Vikas Awasthi)',
    location: 'काकादेव, कानपुर (Kakadeo, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '3 weeks ago',
    rating: 5,
    category: 'kanpur',
    lang: 'hi',
    serviceUsed: 'Classic Milk & Biscoff Chocolates',
    comment:
      'मेरे बेटे के बर्थडे पर क्लासिक मिल्क (₹20) और बिस्कॉफ चॉकलेट्स (₹40) के रिटर्न गिफ्ट्स दिए। सारे बच्चों को बहुत पसंद आई। सेम-डे कानपुर डिलीवरी मिल गई।',
  },
  {
    id: 'gr-5',
    author: 'Priyanka Tulsyan',
    location: 'Swaroop Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '3 weeks ago',
    rating: 5,
    category: 'kunafa_biscoff',
    lang: 'en',
    serviceUsed: 'Kunafa & Biscoff Chocolates (₹50 / ₹40)',
    comment:
      'The Biscoff and Kunafa chocolates are out of this world! You can taste the authentic butter-roasted kataifi and rich pistachio cream. 100% eggless and pure cocoa butter.',
  },
  {
    id: 'gr-6',
    author: 'मोनिका मेहरा (Monika Mehra)',
    location: 'तिलक नगर, कानपुर (Tilak Nagar, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'delivery',
    lang: 'hi',
    serviceUsed: 'Kanpur Express Insulated Delivery',
    comment:
      'कानपुर में सेम-डे express डिलीवरी सर्विस बहुत फ़ास्ट है। व्हाट्सएप (+91 63865 90007) पर आर्डर करने के 3 घंटे में तिलक नगर वाले घर पर चिल्ड बॉक्स आ गया।',
  },
  {
    id: 'gr-7',
    author: 'Amitabh Mehrotra',
    location: 'Tilak Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'delivery',
    lang: 'en',
    serviceUsed: 'Anniversary Ribbon Gift Box (₹1,450)',
    comment:
      'Same-day delivery in Kanpur was a lifesaver for my anniversary! Messaged on WhatsApp around 11 AM and the chilled insulated box reached Tilak Nagar by 3:30 PM. Flawless quality.',
  },
  {
    id: 'gr-8',
    author: 'Dr. Shalini Srivastava',
    location: 'Kakadeo, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'kanpur',
    lang: 'en',
    serviceUsed: 'Rich Dark Chocolate (70% Cocoa ₹25)',
    comment:
      'Finally an authentic artisanal chocolatier in Kanpur! The Rich Dark Chocolate (70% Cocoa) is a masterpiece. Zero palm oil, no artificial flavorings. Clean stone-ground texture.',
  },
  {
    id: 'gr-9',
    author: 'संजय कटियार (Sanjay Katiyar)',
    location: 'फजलगंज / दादा नगर, कानपुर (Fazalganj, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'hampers',
    lang: 'hi',
    serviceUsed: 'Corporate Bulk Custom Branding',
    comment:
      'कॉर्पोरेट बल्क आर्डर के लिए 50 गिफ्ट हैम्पर्स आर्डर किए थे। कंपनी का लोगो कार्ड और कस्टमाइज्ड रिबन लगाकर टाइम पर डिलीवर किया गया। बहुत ही प्रोफेशनल सर्विस!',
  },
  {
    id: 'gr-10',
    author: 'Rajeev & Sunita Agarwal',
    location: 'Arya Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'hampers',
    lang: 'en',
    serviceUsed: 'Roka Sagan Celebration Platter (₹2,950)',
    comment:
      'We chose The Cawnpore Chocos for our daughter’s Roka ceremony. Over 120 guests praised the wooden brass platter with gold leaf chocolates and dried rose petals.',
  },
  {
    id: 'gr-11',
    author: 'पूजा कश्यप (Pooja Kashyap)',
    location: 'शास्त्री नगर, कानपुर (Shastri Nagar, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'kanpur',
    lang: 'hi',
    serviceUsed: 'Crunchy Nut Chocolate (₹30)',
    comment:
      'क्रंची नट और बिस्कॉफ चॉकलेट का कॉम्बिनेशन बेस्ट है। घर में बच्चों और बड़ों सबको बहुत पसंद आया। शुद्ध शाकाहारी और ताज़ा बना हुआ!',
  },
  {
    id: 'gr-12',
    author: 'Kunal Singhania',
    location: 'Mall Road, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'delivery',
    lang: 'en',
    serviceUsed: 'Insulated Thermal Cold Gel Pack Delivery',
    comment:
      'Flawless insulated delivery! Even in Kanpur’s afternoon heat, the chocolates arrived completely solid with cold gel packs inside the thermal pouch. Very responsive on WhatsApp.',
  },
  {
    id: 'gr-13',
    author: 'दीपक शुक्ला (Deepak Shukla)',
    location: 'बर्रा, कानपुर (Barra, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'hampers',
    lang: 'hi',
    serviceUsed: 'Subh Deepavali Shahi Box (₹1,850)',
    comment:
      'शुभ दीपावली शाही बॉक्स बहुत पसंद आया। केसर पिस्ता मेडेलियन और ड्राई फ्रूट रोचर्स का स्वाद एकदम ओरिजिनल था। 100% एगलेस होने से बुजुर्गों ने भी आराम से खाया।',
  },
  {
    id: 'gr-14',
    author: 'Nidhi Tiwari',
    location: 'Kidwai Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'kunafa_biscoff',
    lang: 'en',
    serviceUsed: 'Signature Jewel Bonbons (₹1,150)',
    comment:
      'The jewel-painted bonbons look like gemstones! Ordered the 12-piece box for my husband’s birthday. Espresso ganache and salted caramel centers burst with flavor.',
  },
  {
    id: 'gr-15',
    author: 'अमित निगम (Amit Nigam)',
    location: 'किदवई नगर, कानपुर (Kidwai Nagar, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 4,
    category: 'kanpur',
    lang: 'hi',
    serviceUsed: 'Crunchy Nut & Classic Milk Chocolates',
    comment:
      'चॉकलेट्स का स्वाद बहुत ही अच्छा और रिच है। क्रंची नट चॉकलेट्स (₹30) में बादाम और काजू की मात्रा काफी अच्छी है। सर्विस और पैकिंग 5 स्टार है।',
  },
  {
    id: 'gr-16',
    author: 'Manish Chawla',
    location: 'Govind Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'hampers',
    lang: 'en',
    serviceUsed: 'Corporate Festive Boxes',
    comment:
      'Ordered corporate festive boxes for our factory managers in Govind Nagar. The team customized boxes with festival greetings. Timely dispatch and exceptional quality.',
  },
  {
    id: 'gr-17',
    author: 'Anuradha Saxena',
    location: 'Cantonment (Cantt), Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'kanpur',
    lang: 'en',
    serviceUsed: 'Mamra Almond Rocher Clusters',
    comment:
      'Caramelized Mamra Almond Rochers are addictive! You can tell they use genuine Mamra badam because of the rich natural crunch. Proud to have this in Kanpur.',
  },
  {
    id: 'gr-18',
    author: 'रवि शर्मा (Ravi Sharma)',
    location: 'कल्याणपुर, कानपुर (Kalyanpur, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'kunafa_biscoff',
    lang: 'hi',
    serviceUsed: 'Kunafa Chocolate (₹50)',
    comment:
      'कुनाफा चॉकलेट पहली बार ट्राइ की, एकदम माइंड-ब्लोइंग टेस्ट! बटर रोस्टेड कटैफ़ी और पिस्ता क्रीम का स्वाद बहुत ही यूनिक है। कानपुर में यह नंबर 1 है।',
  },
  {
    id: 'gr-19',
    author: 'Vikramaditya Roy',
    location: 'Lajpat Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'kanpur',
    lang: 'en',
    serviceUsed: '24K Gold Dusted Noir Truffles',
    comment:
      'Hands down the finest chocolate brand in Uttar Pradesh. The 24K gold leaf truffles are on par with Belgian chocolatiers. Velvety melt and rich cacao.',
  },
  {
    id: 'gr-20',
    author: 'हर्ष वर्धन गुप्ता (Harsh Vardhan Gupta)',
    location: 'पनकी, कानपुर (Panki, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'hampers',
    lang: 'hi',
    serviceUsed: 'Celebration Moments Ribbon Box (₹1,450)',
    comment:
      'एनिवर्सरी के लिए सेलिब्रेशन मोमेंट्स बॉक्स मंगाया था। गोल्डन रिबन और कस्टमाइज्ड मैसेज कार्ड बहुत प्यारा लग रहा था। फैमिली को बहुत पसंद आया।',
  },
  {
    id: 'gr-21',
    author: 'Pooja Kashyap',
    location: 'Shastri Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'delivery',
    lang: 'en',
    serviceUsed: 'Kanpur Local Express Dispatch',
    comment:
      'Quick delivery, luxury packaging, and extremely polite customer coordination on WhatsApp (+91 63865 90007). Gift hamper arrived with handwritten note.',
  },
  {
    id: 'gr-22',
    author: 'राहुल भदौरिया (Rahul Bhadauria)',
    location: 'श्याम नगर, कानपुर (Shyam Nagar, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '4 months ago',
    rating: 4,
    category: 'kanpur',
    lang: 'hi',
    serviceUsed: 'Rich Dark & Biscoff Chocolates',
    comment:
      '70% डार्क चॉकलेट और बिस्कॉफ दोनों का टेस्ट लाजवाब है। डिलीवरी थोड़ी जल्दी मिल गई और पैकेजिंग पूरी तरह से चिल्ड और सेफ़ थी।',
  },
  {
    id: 'gr-23',
    author: 'Tanvi Rastogi',
    location: 'Chakeri, Kanpur',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'kanpur',
    lang: 'en',
    serviceUsed: 'Banaras Roast Espresso & Cardamom',
    comment:
      'The Banaras roast espresso bar paired with cardamom is an absolute revelation. Delicate, aromatic dark chocolate combination. Proud this comes from Kanpur!',
  },
  {
    id: 'gr-24',
    author: 'शालिनी त्रिवेदी (Shalini Trivedi)',
    location: 'रावतपुर, कानपुर (Rawatpur, Kanpur)',
    city: 'Kanpur',
    isLocalGuide: false,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'kunafa_biscoff',
    lang: 'hi',
    serviceUsed: 'Biscoff Chocolate (₹40)',
    comment:
      'बिस्कॉफ चॉकलेट का क्रंच और कैरामेल फ्लेवर बहुत ही टेस्टी है। कानपुर में होममेड चॉकलेट्स के लिए द कानपुर चोकोस सबसे बेस्ट ऑप्शन है।',
  },
  {
    id: 'gr-25',
    author: 'Aakash Srivastava',
    location: 'Yashoda Nagar, Kanpur',
    city: 'Kanpur',
    isLocalGuide: true,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'hampers',
    lang: 'en',
    serviceUsed: 'Royal Heritage Hamper Box (₹2,450)',
    comment:
      'Exceptional quality gift box. The gold embossed box seal and rich pralines inside made a stunning impression. Highly recommended for Kanpur gifting.',
  },

  // --- UP & NCR Cities (Reviews 26 to 50) ---
  {
    id: 'gr-26',
    author: 'सुप्रिया सिंह (Supriya Singh)',
    location: 'गोमती नगर, लखनऊ (Gomti Nagar, Lucknow)',
    city: 'Lucknow',
    isLocalGuide: true,
    timeAgo: '2 weeks ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Anniversary Ribbon Box (Inter-City Courier)',
    comment:
      'लखनऊ में रहते हुए हमने कानपुर से अपनी एनिवर्सरी के लिए रिबन गिफ्ट बॉक्स मंगवाया। कोल्ड जेल पैक इन्सुलेटेड पैकिंग की वजह से चॉकलेट्स बिल्कुल भी नहीं पिघलीं।',
  },
  {
    id: 'gr-27',
    author: 'Rohit Malhotra',
    location: 'South Extension, New Delhi',
    city: 'Delhi',
    isLocalGuide: true,
    timeAgo: '2 weeks ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Kunafa & 70% Dark Slabs',
    comment:
      'Ordered to Delhi via courier. The Kunafa chocolate and 70% dark slabs are world-class! Pure cocoa butter and zero palm oil makes all the difference.',
  },
  {
    id: 'gr-28',
    author: 'विवेक पांडे (Vivek Pandey)',
    location: 'सिगरा, वाराणसी (Sigra, Varanasi)',
    city: 'Varanasi',
    isLocalGuide: false,
    timeAgo: '3 weeks ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Awadh Wedding Trousseau Trunk (₹3,600)',
    comment:
      'वाराणसी में हमारे वेडिंग एनिवर्सरी के लिए 36-पीस वेडिंग ट्रस्यू ट्रंक मंगवाया था। ब्रास क्लैप्स बॉक्स और गोल्डन रिबन बहुत खूबसूरत लग रहे थे।',
  },
  {
    id: 'gr-29',
    author: 'Neha Kapoor',
    location: 'Noida Sector 62, Uttar Pradesh',
    city: 'Noida',
    isLocalGuide: true,
    timeAgo: '3 weeks ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Diwali Corporate Gift Box (₹1,850)',
    comment:
      'Delivered safely to Noida in insulated temperature packaging. Saffron pistachio medallions and gold leaf chocolates were fresh and delicious!',
  },
  {
    id: 'gr-30',
    author: 'आलोक चतुर्वेदी (Alok Chaturvedi)',
    location: 'संजय प्लेस, आगरा (Sanjay Place, Agra)',
    city: 'Agra',
    isLocalGuide: false,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Subh Deepavali Shahi Box',
    comment:
      'आगरा में दिवाली के लिए गिफ्ट हैम्पर्स आर्डर किए थे। शुद्ध शाकाहारी और केसर पिस्ता की खुशबू से भरपूर। कानपुर से सुपरफास्ट कूरियर डिलीवरी मिली।',
  },
  {
    id: 'gr-31',
    author: 'Siddharth Joshi',
    location: 'DLF Phase 5, Gurgaon',
    city: 'Gurgaon',
    isLocalGuide: true,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Premium Special Chocolates (₹60+)',
    comment:
      'Brought these premium gold dusted chocolates from Kanpur for our Gurgaon office event. Everyone was amazed by the authentic cocoa butter texture.',
  },
  {
    id: 'gr-32',
    author: 'डॉ. अनन्या मुखर्जी (Dr. Ananya Mukherjee)',
    location: 'हज़रतगंज, लखनऊ (Hazratganj, Lucknow)',
    city: 'Lucknow',
    isLocalGuide: true,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Signature Jewel Bonbons (₹1,150)',
    comment:
      'हज़रतगंज लखनऊ में हमने 12-पीस ज्वेल बोनबोन्स मंगाए। हैंड-पेंटेड बोनबोन्स की फिनिशिंग और एस्प्रेसो गनाश का स्वाद बहुत ही एलगेंट है।',
  },
  {
    id: 'gr-33',
    author: 'Meenakshi Sundaram',
    location: 'Civil Lines, Prayagraj (Allahabad)',
    city: 'Prayagraj',
    isLocalGuide: false,
    timeAgo: '1 month ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Royal Heritage Hamper Box',
    comment:
      'Beautifully packed hamper delivered to Prayagraj in express courier. The rigid box quality and satin ribbon tie makes it a luxury keepsake.',
  },
  {
    id: 'gr-34',
    author: 'प्रवीण सिंघल (Praveen Singhal)',
    location: 'द्वारका, नई दिल्ली (Dwarka, New Delhi)',
    city: 'Delhi',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 4,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Kunafa & Biscoff Chocolates',
    comment:
      'दिल्ली में कूरियर से 2 दिन में आ गया। कुनाफा चॉकलेट का टेस्ट एकदम ऑथेंटिक है। पैकेजिंग में बबल्स और आइस पैक्स लगे हुए थे।',
  },
  {
    id: 'gr-35',
    author: 'Divya Raghuvanshi',
    location: 'Indirapuram, Ghaziabad',
    city: 'Ghaziabad',
    isLocalGuide: true,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Celebration Moments Ribbon Box',
    comment:
      'Ordered for my parent’s 30th anniversary in Ghaziabad. The custom note card and fresh nut pralines made their day extra special!',
  },
  {
    id: 'gr-36',
    author: 'सौरभ माथुर (Saurabh Mathur)',
    location: 'कृष्णा नगर, मथुरा (Mathura, UP)',
    city: 'Mathura',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Awadh Royal Saffron & Pistachio',
    comment:
      'मथुरा में जन्माष्टमी पर्व के लिए प्योर वेज केसर पिस्ता मेडेलियन मंगाए थे। शुद्ध कोको बटर और असली कश्मीरी केसर का स्वाद बहुत ही पवित्र और रिच है।',
  },
  {
    id: 'gr-37',
    author: 'Kavita Deshmukh',
    location: 'Rajpur Road, Dehradun',
    city: 'Dehradun',
    isLocalGuide: true,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Rich Dark & Mamra Almond Rochers',
    comment:
      'Courier reached Dehradun in perfect chilled condition. The Mamra Almond Rochers are crunchy and rich. Highly recommended!',
  },
  {
    id: 'gr-38',
    author: 'मनीष खंडेलवाल (Manish Khandelwal)',
    location: 'सिविल लाइंस, बरेली (Bareilly, UP)',
    city: 'Bareilly',
    isLocalGuide: false,
    timeAgo: '2 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Subh Deepavali Shahi Box',
    comment:
      'बरेली में दीपावली पर रिश्तेदारों को देने के लिए 10 डिब्बे मंगवाए थे। सबने चॉकलेट्स की बहुत तारीफ़ की। कानपुर से टाइम पर dispatch हुआ।',
  },
  {
    id: 'gr-39',
    author: 'Tarun Saxena',
    location: 'Gorakhpur Town, Uttar Pradesh',
    city: 'Gorakhpur',
    isLocalGuide: true,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Royal Roka Ceremony Platter',
    comment:
      'Delivered to Gorakhpur for my brother’s engagement ceremony. Wooden brass platter with dried rose petals looked royal and impressive.',
  },
  {
    id: 'gr-40',
    author: 'अनिल जादौन (Anil Jadaun)',
    location: 'मैरिस रोड, अलीगढ़ (Aligarh, UP)',
    city: 'Aligarh',
    isLocalGuide: false,
    timeAgo: '3 months ago',
    rating: 4,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Crunchy Nut & Classic Milk Chocolates',
    comment:
      'अलीगढ़ कूरियर डिलीवरी में चॉकलेट्स सेफ़ मिलीं। क्रंची नट और मिल्क चॉकलेट्स का टेस्ट बहुत ही बढ़िया और फ्रेश है।',
  },
  {
    id: 'gr-41',
    author: 'Shalini Bhardwaj',
    location: 'Shastri Nagar, Meerut',
    city: 'Meerut',
    isLocalGuide: true,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Biscoff & Kunafa Chocolates',
    comment:
      'Unmatched quality! The Biscoff cookie spread filling and Kunafa kataifi crunch are decadent. Best homemade chocolate brand from UP.',
  },
  {
    id: 'gr-42',
    author: 'दीपक परिहार (Deepak Parihar)',
    location: 'सदर बाज़ार, झांसी (Jhansi, UP)',
    city: 'Jhansi',
    isLocalGuide: false,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Celebration Moments Ribbon Gift Box',
    comment:
      'झांसी में मैरिज एनिवर्सरी पर गिफ्ट बॉक्स मंगाया। पैकिंग बहुत ही खूबसूरत थी और 100% शाकाहारी होने की वजह से पूरी फैमिली ने पसंद किया।',
  },
  {
    id: 'gr-43',
    author: 'Vikrant Chaudhry',
    location: 'Gomti Nagar Extension, Lucknow',
    city: 'Lucknow',
    isLocalGuide: true,
    timeAgo: '3 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Royal Heritage Hamper Box (₹2,450)',
    comment:
      'Ordered from Lucknow via WhatsApp. Quick response, transparent order tracking, and pristine delivery with gel packs.',
  },
  {
    id: 'gr-44',
    author: 'संजय गोस्वामी (Sanjay Goswami)',
    location: 'लंका, वाराणसी (Lanka, Varanasi)',
    city: 'Varanasi',
    isLocalGuide: false,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: '24K Gold Noir Truffles',
    comment:
      '24K गोल्ड लीफ ट्रफल्स का स्वाद बहुत ही शाही है। वाराणसी में कूरियर द्वारा सही सलामत पहुँची। 5 स्टार रेटिंग!',
  },
  {
    id: 'gr-45',
    author: 'Anjali Bisht',
    location: 'Lajpat Nagar, New Delhi',
    city: 'Delhi',
    isLocalGuide: true,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Jewel Bonbons & Kunafa Chocolates',
    comment:
      'Hand-painted bonbons are true edible art! Ordering on WhatsApp was super easy. Will definitely reorder for holiday gifting.',
  },
  {
    id: 'gr-46',
    author: 'रमेश चंद्र यादव (Ramesh Chandra Yadav)',
    location: 'ताजगंज, आगरा (Tajganj, Agra)',
    city: 'Agra',
    isLocalGuide: false,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Classic Milk & Rich Dark Pieces',
    comment:
      'आगरा में कूरियर डिलीवरी से 2 दिन में चॉकलेट्स मिल गईं। डार्क चॉकलेट और मिल्क दोनों में पियोर कोको बटर का ज़बरदस्त मेल्ट है।',
  },
  {
    id: 'gr-47',
    author: 'Naveen Rastogi',
    location: 'Aliganj, Lucknow',
    city: 'Lucknow',
    isLocalGuide: true,
    timeAgo: '4 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Awadh Wedding Trousseau Trunk',
    comment:
      'Ordered wedding favor trunks for Lucknow reception. The velvet brass clasp trunks were heavily praised by all our guests.',
  },
  {
    id: 'gr-48',
    author: 'विवेक राजवंशी (Vivek Rajvanshi)',
    location: 'सिविल लाइंस, प्रयागराज (Prayagraj)',
    city: 'Prayagraj',
    isLocalGuide: false,
    timeAgo: '5 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Subh Deepavali Shahi Box',
    comment:
      'प्रयागराज में फैमिली फंक्शन के लिए गिफ्ट डिब्बे मंगाए। ऑथेंटिक टेस्ट और बहुत ही सुंदर पैकेजिंग। व्हाट्सएप सपोर्ट बहुत हेल्पफुल है।',
  },
  {
    id: 'gr-49',
    author: 'Priyanka Sen',
    location: 'Sector 18, Noida',
    city: 'Noida',
    isLocalGuide: true,
    timeAgo: '5 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'en',
    serviceUsed: 'Biscoff & Crunchy Nut Chocolates',
    comment:
      'Noida delivery was fast and insulated. The speculoos Biscoff crunch center is divine. Best artisanal brand from Uttar Pradesh!',
  },
  {
    id: 'gr-50',
    author: 'मनोज खन्ना (Manoj Khanna)',
    location: 'मॉडल टाउन, बरेली (Bareilly, UP)',
    city: 'Bareilly',
    isLocalGuide: false,
    timeAgo: '5 months ago',
    rating: 5,
    category: 'up_ncr',
    lang: 'hi',
    serviceUsed: 'Celebration Moments Ribbon Box',
    comment:
      'बरेली में बर्थडे के लिए आर्डर किया था। टाइम पर डिलीवरी मिली और रिबन टाई बॉक्स देखने में बहुत लग्जरी लगा। 100% रिकमेंडेड!',
  },
];

export const GoogleReviewsSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'kanpur' | 'up_ncr' | 'hampers' | 'kunafa_biscoff' | 'delivery'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAll, setShowAll] = useState(false);

  const filtered = GOOGLE_REVIEWS.filter((rev) => {
    const matchesCat = activeCategory === 'all' || rev.category === activeCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      rev.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.comment.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.serviceUsed.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const displayedReviews = showAll ? filtered : filtered.slice(0, 9);

  return (
    <section className="bg-[#160c07] border-t border-[#2d1b11] py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header & Google Badge Summary */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 mb-10 pb-8 border-b border-[#2d1b11]">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#e2c678]">
              {/* Google G Icon */}
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>Google Verified Customer Ratings & Reviews</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#f4ede4]">
              Over 2,000+ Verified Customer Ratings
            </h2>
            <p className="text-xs sm:text-sm text-[#d8c2ad] leading-relaxed">
              Real reflections, photos, and verified reviews from chocolate enthusiasts across Kanpur, Lucknow, Varanasi, Delhi NCR, and Uttar Pradesh.
            </p>
          </div>

          {/* Rating Breakdown Badge Card */}
          <div className="bg-[#120905] border border-[#c9a44c]/50 rounded-2xl p-5 flex flex-col sm:flex-row items-center gap-6 shrink-0 shadow-2xl">
            {/* Main Score */}
            <div className="text-center sm:border-r sm:border-[#2d1b11] sm:pr-6">
              <span className="font-mono text-4xl font-extrabold text-[#e2c678] block leading-none">
                4.9
              </span>
              <div className="flex items-center justify-center gap-1 text-[#e2c678] my-1.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#e2c678] text-[#e2c678]" />
                ))}
              </div>
              <span className="text-[11px] text-[#f4ede4] font-semibold block">
                2,050+ Total Ratings
              </span>
            </div>

            {/* Star Distribution Summary */}
            <div className="space-y-2 text-xs w-full sm:w-auto">
              <div className="flex items-center gap-3">
                <span className="text-[11px] text-[#e2c678] font-bold w-12 shrink-0">5 Stars</span>
                <div className="w-32 bg-[#23140c] rounded-full h-2 overflow-hidden border border-[#42281b]">
                  <div className="bg-[#c9a44c] h-full rounded-full w-[90%]" />
                </div>
                <span className="text-[11px] text-[#d8c2ad] font-mono">1,850+</span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[11px] text-[#e2c678] font-bold w-12 shrink-0">4 Stars</span>
                <div className="w-32 bg-[#23140c] rounded-full h-2 overflow-hidden border border-[#42281b]">
                  <div className="bg-[#c9a44c]/70 h-full rounded-full w-[10%]" />
                </div>
                <span className="text-[11px] text-[#d8c2ad] font-mono">200+</span>
              </div>

              <div className="pt-1 border-t border-[#2d1b11]/80 text-[10px] text-[#d8c2ad]/70 flex items-center justify-between">
                <span>The Cawnpore Chocos</span>
                <span className="text-[#34A853] font-semibold">100% Pure Cocoa Butter</span>
              </div>
            </div>
          </div>
        </div>

        {/* Search Bar & Category Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
            {[
              { id: 'all', label: `All Reviews (50)` },
              { id: 'kanpur', label: 'Kanpur Localities (25)' },
              { id: 'up_ncr', label: 'UP & Delhi NCR (25)' },
              { id: 'kunafa_biscoff', label: 'Kunafa & Biscoff' },
              { id: 'hampers', label: 'Gift Hampers' },
              { id: 'delivery', label: 'Insulated Delivery' },
            ].map((tab) => {
              const isActive = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveCategory(tab.id as any);
                    setShowAll(false);
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer border ${
                    isActive
                      ? 'bg-[#c9a44c] text-[#120905] border-[#c9a44c] shadow-md'
                      : 'bg-[#120905] text-[#d8c2ad] border-[#2d1b11] hover:border-[#42281b] hover:text-[#f4ede4]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative shrink-0 sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search locality or city..."
              className="w-full bg-[#120905] border border-[#2d1b11] focus:border-[#c9a44c] rounded-xl px-3.5 py-2 pl-9 text-xs text-[#f4ede4] placeholder-[#d8c2ad]/50 focus:outline-none transition-colors"
            />
            <MapPin className="absolute left-3 top-2.5 w-3.5 h-3.5 text-[#c9a44c]" />
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedReviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#120905] rounded-2xl border border-[#2d1b11] hover:border-[#c9a44c]/60 p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 shadow-md hover:shadow-xl relative overflow-hidden group"
            >
              <div>
                {/* Top Bar: Author & Star Rating */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#c9a44c] via-[#42281b] to-[#120905] p-[1px] flex items-center justify-center shrink-0">
                      <div className="w-full h-full rounded-full bg-[#1a0e08] flex items-center justify-center font-bold text-xs text-[#e2c678]">
                        {rev.author.charAt(0)}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-xs text-[#f4ede4]">{rev.author}</span>
                        {rev.isLocalGuide && (
                          <span className="text-[9px] text-[#e2c678] font-mono bg-[#1a0e08] border border-[#c9a44c]/40 px-1.5 py-0.2 rounded font-semibold uppercase">
                            Local Guide
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-[#d8c2ad]/70 block flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-[#c9a44c] shrink-0" />
                        <span>{rev.location}</span>
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] text-[#d8c2ad]/50 shrink-0 font-mono">{rev.timeAgo}</span>
                </div>

                {/* Stars + Service Used Badge */}
                <div className="flex items-center justify-between gap-2 my-3 pb-3 border-b border-[#2d1b11]">
                  <div className="flex items-center gap-0.5">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#e2c678] text-[#e2c678]" />
                    ))}
                  </div>
                  <span className="text-[10px] font-semibold text-[#e2c678] bg-[#23140c] px-2 py-0.5 rounded border border-[#42281b]">
                    {rev.serviceUsed}
                  </span>
                </div>

                {/* Comment Body */}
                <p className="text-xs text-[#d8c2ad] leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Verified Badge Footer */}
              <div className="pt-3 mt-4 border-t border-[#1a0e08] flex items-center justify-between text-[10px] text-[#c9a44c]">
                <span className="flex items-center gap-1 font-medium">
                  <CheckCircle className="w-3.5 h-3.5 text-[#34A853]" />
                  <span>Verified Google Patron</span>
                </span>
                <span className="text-[#d8c2ad]/50 uppercase tracking-wider font-mono">{rev.city}</span>
              </div>
            </div>
          ))}
        </div>

        {/* View All Reviews Button */}
        {filtered.length > 9 && (
          <div className="mt-10 text-center">
            <button
              onClick={() => setShowAll(!showAll)}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#120905] hover:bg-[#1a0e08] border border-[#c9a44c]/60 hover:border-[#c9a44c] text-xs font-bold uppercase tracking-wider text-[#e2c678] rounded-xl transition-all cursor-pointer shadow-lg"
            >
              <span>{showAll ? 'Show Fewer Reviews' : `Read All ${filtered.length} Verified Customer Reviews`}</span>
              {showAll ? <ChevronUp className="w-4 h-4 text-[#e2c678]" /> : <ChevronDown className="w-4 h-4 text-[#e2c678]" />}
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
