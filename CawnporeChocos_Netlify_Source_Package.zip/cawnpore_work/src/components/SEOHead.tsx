import React, { useEffect } from 'react';
import { Product } from '../types/chocolate';

interface SEOHeadProps {
  currentPage: string;
  selectedProduct?: Product | null;
}

export const SEOHead: React.FC<SEOHeadProps> = ({ currentPage, selectedProduct }) => {
  useEffect(() => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const logoUrl = `${origin}/assets/aistudio/b98e282f-669f-4e25-8d89-8108452098c8_1f146091.jpeg`;

    let title = 'The Cawnpore Chocos | Best Homemade Chocolate Brand in Kanpur';
    let description = 'The Cawnpore Chocos is the best homemade chocolate brand in Kanpur, offering handmade chocolates, custom gift hampers, and festive boxes in Kanpur, Uttar Pradesh. Direct WhatsApp order (+91 6386590007).';
    let canonicalUrl = `${origin}/#${currentPage}`;

    if (selectedProduct) {
      title = `${selectedProduct.name} | The Cawnpore Chocos Kanpur`;
      description = `${selectedProduct.description} Handcrafted with pure cocoa butter, eggless, zero palm oil. Available for delivery in Kanpur, Uttar Pradesh.`;
      canonicalUrl = `${origin}/#product=${selectedProduct.id}`;
    } else {
      switch (currentPage) {
        case 'home':
          title = 'The Cawnpore Chocos | Best Homemade Chocolate Brand in Kanpur';
          description = 'Discover Kanpur\'s favorite homemade chocolate gift brand. Micro-batch handmade chocolates, gold-dusted truffles, and luxury gift hampers in Kanpur, Uttar Pradesh.';
          canonicalUrl = `${origin}/#home`;
          break;
        case 'chocolates':
          title = 'Handmade Chocolates in Kanpur | Luxury Single-Origin Dark & Bonbons';
          description = 'Shop handmade chocolates in Kanpur, including 74% dark chocolate slabs, Awadh saffron pistachio medallions, and jewel bonbons. Pure cocoa butter, 100% vegetarian.';
          canonicalUrl = `${origin}/#chocolates`;
          break;
        case 'hampers':
          title = 'Chocolate Gift Hampers in Kanpur | Custom Gift Boxes | The Cawnpore Chocos';
          description = 'Order premium chocolate gift hampers in Kanpur for Diwali, weddings, Roka ceremonies, anniversaries, and birthdays. Custom gold foil rigid gift boxes with satin ribbons.';
          canonicalUrl = `${origin}/#hampers`;
          break;
        case 'festivals':
          title = 'Festive Chocolate Gifts in Uttar Pradesh & Kanpur | The Cawnpore Chocos';
          description = 'Explore festive chocolate gift hampers for Diwali, Christmas, Birthdays, Weddings, Roka, and Children\'s Day from Kanpur\'s premier homemade chocolate brand.';
          canonicalUrl = `${origin}/#festivals`;
          break;
        case 'track-order':
          title = 'Track Kanpur Chocolate Order Delivery | The Cawnpore Chocos';
          description = 'Track your chocolate delivery in Kanpur in real-time. Enter your Order ID to check live batch preparation and express delivery status across Kanpur.';
          canonicalUrl = `${origin}/#track-order`;
          break;
        case 'about':
          title = 'About The Cawnpore Chocos | Best Homemade Chocolate Brand in Kanpur';
          description = 'Learn about The Cawnpore Chocos in Kanpur, Uttar Pradesh. Handcrafted with pure cocoa butter, local botanicals, and eggless recipes. FAQs on Kanpur delivery & storage.';
          canonicalUrl = `${origin}/#about`;
          break;
        case 'contact':
          title = 'Contact & Bulk Order Enquiry | The Cawnpore Chocos Kanpur';
          description = 'Contact The Cawnpore Chocos in Kanpur. Direct WhatsApp ordering (+91 63865 90007), bulk corporate gifts, custom wedding hampers, and boutique location.';
          canonicalUrl = `${origin}/#contact`;
          break;
        default:
          break;
      }
    }

    // Update Document Title
    document.title = title;

    // Helper to set or update meta tag
    const setMetaTag = (selectorName: string, attributeValue: string, content: string) => {
      let element = document.querySelector(`meta[${selectorName}="${attributeValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(selectorName, attributeValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    // Standard SEO
    setMetaTag('name', 'description', description);

    // OpenGraph Tags
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:url', canonicalUrl);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('property', 'og:site_name', 'The Cawnpore Chocos');
    setMetaTag('property', 'og:image', selectedProduct ? (selectedProduct.image.startsWith('http') ? selectedProduct.image : `${origin}${selectedProduct.image}`) : logoUrl);

    // Twitter Card Tags
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', selectedProduct ? (selectedProduct.image.startsWith('http') ? selectedProduct.image : `${origin}${selectedProduct.image}`) : logoUrl);

    // Update Canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonicalUrl);

    // Dynamic JSON-LD Structured Data
    let schemaScript = document.getElementById('seo-dynamic-jsonld') as HTMLScriptElement | null;
    if (!schemaScript) {
      schemaScript = document.createElement('script');
      schemaScript.id = 'seo-dynamic-jsonld';
      schemaScript.type = 'application/ld+json';
      document.head.appendChild(schemaScript);
    }

    if (selectedProduct) {
      const productSchema = {
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: selectedProduct.name,
        image: selectedProduct.image.startsWith('http') ? selectedProduct.image : `${origin}${selectedProduct.image}`,
        description: selectedProduct.description,
        brand: {
          '@type': 'Brand',
          name: 'The Cawnpore Chocos',
          logo: logoUrl,
        },
        offers: {
          '@type': 'Offer',
          priceCurrency: 'INR',
          price: selectedProduct.price,
          availability: 'https://schema.org/InStock',
          url: canonicalUrl,
          seller: {
            '@type': 'Organization',
            name: 'The Cawnpore Chocos',
          },
        },
      };
      schemaScript.textContent = JSON.stringify(productSchema);
    } else {
      const localBusinessSchema = {
        '@context': 'https://schema.org',
        '@type': 'LocalBusiness',
        name: 'The Cawnpore Chocos',
        image: logoUrl,
        logo: logoUrl,
        '@id': `${origin}/#store`,
        url: origin,
        telephone: '+91-6386590007',
        email: 'thecawnporechocos@gmail.com',
        priceRange: '₹₹',
        address: {
          '@type': 'PostalAddress',
          streetAddress: 'Swaroop Nagar / Civil Lines',
          addressLocality: 'Kanpur',
          addressRegion: 'Uttar Pradesh',
          postalCode: '208001',
          addressCountry: 'IN',
        },
        geo: {
          '@type': 'GeoCoordinates',
          latitude: 26.4499,
          longitude: 80.3319,
        },
        openingHoursSpecification: [
          {
            '@type': 'OpeningHoursSpecification',
            dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
            opens: '09:00',
            closes: '21:00',
          },
        ],
        sameAs: ['https://www.instagram.com/thecawnporechocos'],
        description: 'The Cawnpore Chocos is the best homemade chocolate brand in Kanpur, crafting handmade chocolates, custom festive gift hampers, wedding favors, and birthday chocolate boxes in Kanpur, Uttar Pradesh.',
      };
      schemaScript.textContent = JSON.stringify(localBusinessSchema);
    }
  }, [currentPage, selectedProduct]);

  return null;
};
