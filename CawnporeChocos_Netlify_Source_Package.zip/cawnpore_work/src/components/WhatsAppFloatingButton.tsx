import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { DISPLAY_PHONE, WHATSAPP_NUMBER } from '../utils/whatsapp';

export const WhatsAppFloatingButton: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Namaste The Cawnpore Chocos! I would like to enquire about ordering your handcrafted chocolates.'
  )}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Tooltip banner */}
      {showTooltip && (
        <div className="mb-2 bg-[#1a0e08] border border-[#c9a44c]/60 shadow-xl rounded-xl p-3 max-w-[220px] text-xs text-[#f4ede4] animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-start justify-between gap-1">
            <span className="font-semibold text-[#e2c678] text-[11px] uppercase tracking-wider block">
              Direct Confectioner Chat
            </span>
            <button
              onClick={() => setShowTooltip(false)}
              className="text-[#d8c2ad]/60 hover:text-[#f4ede4] p-0.5 cursor-pointer"
              aria-label="Dismiss chat tooltip"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <p className="text-[11px] text-[#d8c2ad] mt-1 leading-snug">
            Order directly or customize your gift hamper on WhatsApp.
          </p>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer"
        aria-label={`Chat with The Cawnpore Chocos on WhatsApp at ${DISPLAY_PHONE}`}
      >
        <MessageCircle className="w-6 h-6 fill-current text-white shrink-0" />
        <span className="hidden sm:inline-block text-xs font-bold tracking-wide text-white uppercase whitespace-nowrap">
          Order on WhatsApp
        </span>
      </a>
    </div>
  );
};
