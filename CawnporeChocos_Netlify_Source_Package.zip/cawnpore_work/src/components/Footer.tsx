import React from 'react';
import { MessageCircle, Mail, MapPin, ShieldCheck, Heart, Star } from 'lucide-react';
import { BRAND_EMAIL, BRAND_LOCATION, DISPLAY_PHONE, WHATSAPP_NUMBER } from '../utils/whatsapp';
import { BRAND_LOGO } from '../data/products';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Namaste The Cawnpore Chocos! I would like to enquire about your artisanal chocolates.'
  )}`;

  return (
    <footer className="bg-[#120905] border-t border-[#2d1b11] text-[#d8c2ad] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Trust Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pb-12 border-b border-[#2d1b11]">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#1e120a] border border-[#42281b] flex items-center justify-center text-[#e2c678] shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#f4ede4] tracking-wide">100% Pure Cocoa Butter</h4>
              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                Handcrafted without hydrogenated vegetable oils or compound chocolate substitutes.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#1e120a] border border-[#42281b] flex items-center justify-center text-[#e2c678] shrink-0">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#f4ede4] tracking-wide">Pure Vegetarian (Eggless)</h4>
              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                All chocolates, truffles, and festive gift assortments are strictly vegetarian and eggless.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#1e120a] border border-[#42281b] flex items-center justify-center text-[#e2c678] shrink-0">
              <Star className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#f4ede4] tracking-wide">5.0 ★ Google Rated</h4>
              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                Kanpur's top-rated artisanal chocolate brand with 100% 5-star customer feedback.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#1e120a] border border-[#42281b] flex items-center justify-center text-[#e2c678] shrink-0">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#f4ede4] tracking-wide">Direct WhatsApp Orders</h4>
              <p className="text-xs text-[#d8c2ad]/80 mt-1">
                Freshly prepared to order. Fast doorstep delivery coordination in Kanpur.
              </p>
            </div>
          </div>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 py-12">
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#c9a44c] via-[#42281b] to-[#120905] p-[1.5px] flex items-center justify-center shrink-0 overflow-hidden">
                <div className="w-full h-full rounded-full bg-[#120905] flex items-center justify-center overflow-hidden">
                  <img
                    src={BRAND_LOGO}
                    alt="The Cawnpore Chocos"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
              </div>
              <div>
                <span className="font-serif text-xl text-[#f4ede4] tracking-wider block font-semibold">
                  The Cawnpore Chocos
                </span>
                <span className="text-[11px] text-[#e2c678] font-medium block">
                  Every Occasion, A Sweet Expression
                </span>
              </div>
            </div>
            <p className="text-xs text-[#d8c2ad] leading-relaxed">
              Kanpur’s favourite luxury chocolate brand. Pure cocoa butter, zero palm oil, 100% vegetarian confections handcrafted with devotion in Kanpur, Uttar Pradesh.
            </p>
            <div className="pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#e2c678] hover:text-[#f4ede4] transition-colors"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Chat with us on WhatsApp (+91 63865 90007)</span>
              </a>
            </div>
          </div>

          {/* Catalog Links */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] mb-4">
              Explore Collections
            </h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('chocolates')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  All Artisanal Chocolates
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('hampers')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Luxury Gift Hampers
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('festivals')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Festival & Wedding Boxes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('track-order')}
                  className="hover:text-[#e2c678] font-semibold text-[#e2c678] transition-colors cursor-pointer"
                >
                  Track Kanpur Delivery Status
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('chocolates')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Single-Origin Dark Bars
                </button>
              </li>
            </ul>
          </div>

          {/* Occasions */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] mb-4">
              Occasions & Gifting
            </h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('festivals')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Diwali Gift Hampers
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('festivals')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Christmas & Winter Treats
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('festivals')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Children’s Day Confections
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('festivals')}
                  className="hover:text-[#f4ede4] transition-colors cursor-pointer"
                >
                  Weddings & Return Favors
                </button>
              </li>
            </ul>
          </div>

          {/* Verified Contact Details */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-[#e2c678] mb-4">
              Contact & Confectionery
            </h5>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#c9a44c] shrink-0 mt-0.5" />
                <span>{BRAND_LOCATION}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#c9a44c] shrink-0" />
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#e2c678] transition-colors font-mono"
                >
                  {DISPLAY_PHONE}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#c9a44c] shrink-0" />
                <a
                  href={`mailto:${BRAND_EMAIL}`}
                  className="hover:text-[#e2c678] transition-colors"
                >
                  {BRAND_EMAIL}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#2d1b11] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#ab8534]">
          <p>© {new Date().getFullYear()} The Cawnpore Chocos. Handcrafted with devotion in Kanpur, India.</p>
          <div className="flex items-center gap-4 text-[#d8c2ad]/70">
            <span>Fresh Micro-Batch Confectionery</span>
            <span aria-hidden="true">·</span>
            <span>All Orders Confirmed via WhatsApp</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
