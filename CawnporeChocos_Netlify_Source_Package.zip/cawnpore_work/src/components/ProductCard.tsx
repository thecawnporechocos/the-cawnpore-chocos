import React, { useState } from 'react';
import { MessageCircle, Plus, Eye, Check } from 'lucide-react';
import { Product } from '../types/chocolate';
import { getProductOrderWhatsAppUrl } from '../utils/whatsapp';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  onAddToCart,
}) => {
  const [imageError, setImageError] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const whatsappUrl = getProductOrderWhatsAppUrl(product, 1);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  return (
    <div
      onClick={() => onSelect(product)}
      className="group relative bg-[#1a0e08] rounded-xl border border-[#2d1b11] hover:border-[#c9a44c]/80 transition-all duration-300 ease-out flex flex-col overflow-hidden cursor-pointer shadow-md hover:shadow-[0_12px_30px_rgba(201,164,76,0.15)] hover:-translate-y-1.5 active:scale-[0.985]"
    >
      {/* Product Image Container */}
      <div className="relative aspect-[4/3] w-full bg-[#120905] overflow-hidden">
        {!imageError ? (
          <img
            src={product.image}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#23140c] to-[#120905]">
            <span className="font-serif text-lg text-[#e2c678]">{product.name}</span>
            <span className="text-xs text-[#d8c2ad]/60 mt-1">{product.weight}</span>
          </div>
        )}

        {/* Subtle Gold Shimmer Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a0e08] via-transparent to-transparent opacity-60 group-hover:opacity-30 transition-opacity duration-300" />

        {/* Bestseller / Signature Craft Tag */}
        {product.isBestseller && (
          <div className="absolute top-3 left-3 bg-[#120905]/90 backdrop-blur-md border border-[#c9a44c]/60 px-2.5 py-1 rounded text-[10px] font-semibold text-[#e2c678] tracking-wider uppercase shadow-md group-hover:border-[#e2c678] transition-colors">
            Signature Craft
          </div>
        )}

        {/* Quick View Hover Overlay Button */}
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
          <span className="inline-flex items-center gap-2 px-4 py-2 bg-[#120905]/90 text-xs font-semibold text-[#f4ede4] rounded-lg backdrop-blur-md border border-[#c9a44c]/60 shadow-lg transform group-hover:scale-105 transition-all">
            <Eye className="w-3.5 h-3.5 text-[#e2c678]" />
            <span>View Details</span>
          </span>
        </div>
      </div>

      {/* Content Section */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata */}
          <div className="flex items-center gap-2 text-xs text-[#d8c2ad]/80 tracking-wide mb-1.5 font-mono">
            <span>{product.cocoaPercentage}% Cocoa</span>
            <span aria-hidden="true" className="text-[#c9a44c]">·</span>
            <span>{product.weight}</span>
          </div>

          {/* Title */}
          <h3 className="font-serif text-lg font-semibold text-[#f4ede4] group-hover:text-[#e2c678] transition-colors duration-200 leading-snug line-clamp-2">
            {product.name}
          </h3>

          {/* Subtitle */}
          <p className="text-xs text-[#d8c2ad]/70 mt-1 line-clamp-1">
            {product.subtitle}
          </p>

          {/* Tasting Notes */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2.5 text-[11px] text-[#c9a44c]">
            {product.tastingNotes.slice(0, 3).map((note, idx) => (
              <span key={idx} className="after:content-['·'] last:after:content-none after:ml-1.5 after:text-[#5c3927]">
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Price and Action Buttons */}
        <div className="pt-4 mt-4 border-t border-[#2d1b11] flex items-center justify-between gap-2">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-[#d8c2ad]/60 block">Price</span>
            <span className="font-mono tabular-nums text-lg font-bold text-[#e2c678]">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Add to Bag */}
            <button
              onClick={handleQuickAdd}
              className={`p-2.5 rounded-lg border transition-all duration-200 cursor-pointer active:scale-90 ${
                addedAnimation
                  ? 'bg-emerald-950 border-emerald-500 text-emerald-400 shadow-md scale-105'
                  : 'bg-[#23140c] border-[#42281b] text-[#d8c2ad] hover:text-[#f4ede4] hover:border-[#c9a44c] hover:bg-[#2d1b11]'
              }`}
              title="Add to Enquiry Bag"
              aria-label="Add to Enquiry Bag"
            >
              {addedAnimation ? <Check className="w-4 h-4 animate-in zoom-in-50 duration-200" /> : <Plus className="w-4 h-4" />}
            </button>

            {/* Direct WhatsApp Order Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-bold uppercase tracking-wider rounded-lg transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md active:scale-95"
              title="Order this chocolate via WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>Order</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
