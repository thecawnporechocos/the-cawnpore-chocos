import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, MessageCircle, Search } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../utils/whatsapp';
import { BRAND_LOGO } from '../data/products';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string, filter?: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  cartCount,
  onOpenCart,
  onOpenSearch,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'chocolates', label: 'Our Chocolates' },
    { id: 'hampers', label: 'Gift Hampers' },
    { id: 'festivals', label: 'Festival Collections' },
    { id: 'track-order', label: 'Track Order' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleNavClick = (pageId: string) => {
    onNavigate(pageId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappDirectUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Namaste The Cawnpore Chocos! I would like to enquire about your luxury handcrafted chocolates.'
  )}`;

  const [isBannerVisible, setIsBannerVisible] = useState(true);

  useEffect(() => {
    if (localStorage.getItem('announcementBannerDismissed')) {
      setIsBannerVisible(false);
    }
  }, []);

  const dismissBanner = () => {
    setIsBannerVisible(false);
    localStorage.setItem('announcementBannerDismissed', 'true');
  };

  return (
    <>
      {/* Top Announcements Bar */}
      {isBannerVisible && (
        <div className="bg-[#120905] border-b border-[#2d1b11] py-2 px-4 text-center text-xs text-[#d8c2ad] tracking-wide relative flex items-center justify-center">
          <span className="text-[#e2c678] font-medium">Kanpur Favourite Chocolate Gift Brand</span>
          <span className="mx-2 text-[#ab8534]" aria-hidden="true">·</span>
          <span className="italic text-[#f4ede4]">“Every Occasion, A Sweet Expression”</span>
          <span className="mx-2 text-[#ab8534] hidden sm:inline" aria-hidden="true">·</span>
          <span className="hidden sm:inline">Direct WhatsApp: <strong className="text-[#e2c678] font-normal">+91 63865 90007</strong></span>
          <button 
            onClick={dismissBanner}
            className="absolute right-4 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Header adhering to Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-[#1a0e08]/95 backdrop-blur-md border-b border-[#2d1b11] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single Brand Wordmark with Official Certified Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none cursor-pointer"
          >
            <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#c9a44c] via-[#42281b] to-[#1a0e08] p-[1.5px] flex items-center justify-center shrink-0 shadow-sm overflow-hidden">
              <div className="w-full h-full rounded-full bg-[#120905] flex items-center justify-center overflow-hidden">
                <img
                  src={BRAND_LOGO}
                  alt="The Cawnpore Chocos"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
            </div>
            <div className="whitespace-nowrap shrink-0">
              <span className="font-serif text-lg sm:text-xl text-[#f4ede4] tracking-wider block group-hover:text-[#e2c678] transition-colors leading-tight font-semibold">
                The Cawnpore Chocos
              </span>
              <span className="text-[10px] tracking-wider text-[#e2c678] font-medium block">
                Every Occasion, A Sweet Expression
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#d8c2ad]">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4ede4] cursor-pointer ${
                    isActive ? 'text-[#e2c678] font-semibold' : ''
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#c9a44c]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & WhatsApp CTA */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#d8c2ad] hover:text-[#f4ede4] transition-colors rounded-lg hover:bg-[#2d1b11] cursor-pointer"
              aria-label="Search chocolates"
              title="Search chocolates"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Enquiry Bag Button */}
            <button
              onClick={onOpenCart}
              className="relative p-2 text-[#d8c2ad] hover:text-[#f4ede4] transition-colors rounded-lg hover:bg-[#2d1b11] cursor-pointer"
              aria-label="View Enquiry Bag"
              title="View Enquiry Bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#c9a44c] text-[#120905] text-[10px] font-bold rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Primary Action Button */}
            <a
              href={whatsappDirectUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#120905] bg-[#c9a44c] hover:bg-[#e2c678] rounded-md transition-all whitespace-nowrap shadow-sm hover:shadow-md cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp Order</span>
            </a>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#d8c2ad] hover:text-[#f4ede4] rounded-lg hover:bg-[#2d1b11] focus:outline-none cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#1a0e08] border-b border-[#2d1b11] px-4 pt-3 pb-6 animate-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-3 pb-3 border-b border-[#2d1b11] mb-2">
              <div className="w-10 h-10 rounded-full overflow-hidden p-0.5 bg-[#120905] border border-[#c9a44c]/40 shrink-0">
                <img
                  src={BRAND_LOGO}
                  alt="The Cawnpore Chocos"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div>
                <span className="font-serif text-base text-[#f4ede4] font-semibold block">The Cawnpore Chocos</span>
                <span className="text-[10px] text-[#e2c678] font-medium block">Every Occasion, A Sweet Expression</span>
              </div>
            </div>
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`text-left py-2.5 px-3 rounded-lg text-base font-medium transition-colors cursor-pointer ${
                    currentPage === link.id
                      ? 'bg-[#2d1b11] text-[#e2c678] font-semibold'
                      : 'text-[#d8c2ad] hover:bg-[#23140c] hover:text-[#f4ede4]'
                  }`}
                >
                  {link.label}
                </button>
              ))}

              <div className="pt-4 border-t border-[#2d1b11] flex flex-col gap-3">
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full py-3 text-sm font-semibold text-[#120905] bg-[#c9a44c] rounded-md shadow"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>WhatsApp: +91 63865 90007</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
