import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, MessageCircle, ShoppingBag, ArrowRight, CheckCircle2, Sparkles, Tag, Loader2 } from 'lucide-react';
import { CartItem } from '../types/chocolate';
import { WHATSAPP_NUMBER, buildWhatsAppUrl } from '../utils/whatsapp';
import { createLocalOrderRecord } from '../services/orderStorage';

interface EnquiryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onNavigateToShop: () => void;
}

export const EnquiryDrawer: React.FC<EnquiryDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onNavigateToShop,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryCity, setDeliveryCity] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryPincode, setDeliveryPincode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  if (!isOpen) return null;

  const grandTotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const totalItemsCount = items.reduce((sum, item) => sum + item.quantity, 0);

  // Bulk Order Discount Rule: 10% discount on 51+ boxes
  const isBulkEligible = totalItemsCount >= 51;
  const discountAmount = isBulkEligible ? Math.round(grandTotal * 0.10) : 0;
  const finalAmount = grandTotal - discountAmount;

  const handleCheckout = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const itemsSummary = items
      .map(
        (item, idx) =>
          `${idx + 1}. ${item.product.name} (${item.product.weight}) × ${item.quantity} = ₹${(
            item.product.price * item.quantity
          ).toLocaleString('en-IN')}`
      )
      .join('\n');

    // 1. Create a local order reference
    const { orderId } = createLocalOrderRecord({
      customerName: customerName || 'Direct Customer',
      phone: customerPhone || 'Via WhatsApp',
      mobile: customerPhone || 'Via WhatsApp',
      city: deliveryCity || 'Kanpur',
      address: deliveryAddress || '',
      pincode: deliveryPincode || '',
      items,
      itemsSummary: items.map((i) => `${i.product.name} (x${i.quantity})`).join(', '),
      totalAmount: finalAmount,
      notes: isBulkEligible ? `Bulk Order 10% Discount Applied (-₹${discountAmount})` : 'Standard Order',
      source: 'Website Cart Order',
    });

    setSubmitSuccess(true);
    setIsSubmitting(false);

    // 2. Prepare pre-filled WhatsApp message including the matching Order ID and Bulk Discount breakdown
    const addressLine = deliveryAddress
      ? `${deliveryAddress}, ${deliveryCity || 'Kanpur'}${deliveryPincode ? ` - ${deliveryPincode}` : ''}`
      : (deliveryCity || 'Kanpur');

    const message = `Namaste The Cawnpore Chocos!

*Order Reference:* ${orderId}

*Customer Details:*
• Name: ${customerName || 'Valued Customer'}
• Mobile: ${customerPhone || 'Via WhatsApp'}
• Delivery Address: ${addressLine}

*Items Ordered:*
${itemsSummary}

*Subtotal:* ₹${grandTotal.toLocaleString('en-IN')}
${isBulkEligible ? `*Bulk Order Discount (10% for 51+ boxes):* -₹${discountAmount.toLocaleString('en-IN')}\n` : ''}*Final Payable Amount:* ₹${finalAmount.toLocaleString('en-IN')}

Please confirm order receipt, packaging, and dispatch timeline. Thank you!`;

    const whatsappUrl = buildWhatsAppUrl(message);

    // 3. Open WhatsApp in new tab
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm flex justify-end">
      <div
        className="w-full max-w-md bg-[#1a0e08] h-full flex flex-col border-l border-[#42281b] shadow-2xl animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-[#2d1b11] flex items-center justify-between bg-[#120905]">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#c9a44c]" />
            <h3 className="font-serif text-lg font-semibold text-[#f4ede4]">
              Enquiry Bag ({totalItemsCount})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#d8c2ad] hover:text-[#f4ede4] rounded-lg hover:bg-[#2d1b11] transition-colors cursor-pointer"
            aria-label="Close Enquiry Bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bulk Order Banner Notice inside Drawer */}
        <div className="bg-gradient-to-r from-[#23140c] via-[#1a0e08] to-[#23140c] border-b border-[#c9a44c]/30 p-3 text-center text-xs text-[#d8c2ad]">
          <div className="flex items-center justify-center gap-1.5 text-[#e2c678] font-semibold mb-0.5">
            <Tag className="w-3.5 h-3.5 text-[#c9a44c]" />
            <span>BULK ORDER OFFER: GET 10% OFF ON 51+ BOXES</span>
          </div>
          <p className="text-[10px] text-[#d8c2ad]/80">
            {isBulkEligible
              ? `🎉 Congratulations! You have added ${totalItemsCount} boxes. 10% bulk discount is active (-₹${discountAmount.toLocaleString('en-IN')}).`
              : `Add ${Math.max(0, 51 - totalItemsCount)} more boxes to unlock an automatic 10% bulk order discount.`}
          </p>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#23140c] border border-[#42281b] flex items-center justify-center text-[#c9a44c]">
                <ShoppingBag className="w-8 h-8 opacity-60" />
              </div>
              <div>
                <h4 className="font-serif text-lg text-[#f4ede4]">Your Bag is Empty</h4>
                <p className="text-xs text-[#d8c2ad]/70 mt-1 max-w-xs">
                  Explore our handcrafted dark bars, bonbons, and royal gift hampers to assemble your order enquiry.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onNavigateToShop();
                }}
                className="px-5 py-2.5 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Browse Our Chocolates
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {items.map((item) => (
                <div
                  key={item.product.id}
                  className="bg-[#120905] p-3.5 rounded-xl border border-[#2d1b11] flex gap-3.5 items-start"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-[#23140c] shrink-0 border border-[#42281b]"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-serif text-sm font-semibold text-[#f4ede4] truncate">
                      {item.product.name}
                    </h5>
                    <p className="text-[11px] text-[#d8c2ad]/70 mt-0.5">
                      {item.product.weight} · {item.product.cocoaPercentage}% Cocoa
                    </p>
                    {item.customNote && (
                      <p className="text-[10px] text-[#c9a44c] italic mt-0.5 truncate">
                        "{item.customNote}"
                      </p>
                    )}
                    <div className="flex items-center justify-between mt-2.5">
                      <div className="flex items-center gap-2 bg-[#1a0e08] border border-[#42281b] rounded-md p-0.5">
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                          className="p-1 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-mono tabular-nums text-xs font-semibold text-[#e2c678] px-1.5 min-w-[18px] text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                          className="p-1 text-[#d8c2ad] hover:text-[#f4ede4] cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2.5">
                        <span className="font-mono tabular-nums text-xs font-bold text-[#e2c678]">
                          ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                        </span>
                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="text-[#d8c2ad]/50 hover:text-red-400 transition-colors p-1 cursor-pointer"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Drawer Footer with Enquiry Submission */}
        {items.length > 0 && (
          <div className="p-5 border-t border-[#2d1b11] bg-[#120905] space-y-3.5">
            {/* Customer Delivery Details for WhatsApp */}
            <div className="space-y-2.5 bg-[#160c07] p-3 rounded-xl border border-[#2d1b11]">
              <span className="text-[11px] font-semibold text-[#e2c678] uppercase tracking-wider block">
                Delivery & Contact Details
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ananya Verma"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="col-span-2">
                  <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Kanpur"
                    value={deliveryCity}
                    onChange={(e) => setDeliveryCity(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">PIN Code *</label>
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="208001"
                    value={deliveryPincode}
                    onChange={(e) => setDeliveryPincode(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">Full Delivery Address *</label>
                <input
                  type="text"
                  placeholder="House/Flat No., Road/Locality, Landmark"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c]"
                />
              </div>

              <div>
                <label className="block text-[10px] text-[#d8c2ad]/80 mb-1">Personalized Message for Hamper</label>
                <textarea
                  placeholder="e.g. Happy Birthday to you! - With Love"
                  value={items[0]?.customNote || ''}
                  onChange={(e) => {
                    // This is a simplified approach, as there might be multiple items.
                    // For now, updating the first item as a quick implementation.
                    // A better approach would be per-item notes.
                    onUpdateQuantity(items[0].product.id, items[0].quantity); // Dummy to trigger update logic
                    items[0].customNote = e.target.value; 
                  }}
                  className="w-full px-2.5 py-1.5 bg-[#120905] border border-[#42281b] rounded text-[#f4ede4] text-xs placeholder-[#d8c2ad]/40 focus:outline-none focus:border-[#c9a44c] h-20"
                />
              </div>
            </div>

            {/* Price Breakdown */}
            <div className="space-y-1 pt-1 text-xs">
              <div className="flex items-baseline justify-between text-[#d8c2ad]/80">
                <span>Subtotal ({totalItemsCount} boxes):</span>
                <span className="font-mono tabular-nums">₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>
              {isBulkEligible && (
                <div className="flex items-baseline justify-between text-[#e2c678]">
                  <span>Bulk Order Discount (10% off for 51+ boxes):</span>
                  <span className="font-mono tabular-nums">-₹{discountAmount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex items-baseline justify-between pt-1 border-t border-[#2d1b11]">
                <span className="text-xs font-semibold text-[#f4ede4]">Final Payable Total:</span>
                <span className="font-mono tabular-nums text-xl font-bold text-[#e2c678]">
                  ₹{finalAmount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {submitSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-950/70 border border-emerald-600/40 text-emerald-300 text-[11px] flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Order reference saved on this device. Please send the WhatsApp message to confirm.</span>
              </div>
            )}

            {/* WhatsApp Send Order Button */}
            <button
              onClick={handleCheckout}
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-[#c9a44c] hover:bg-[#e2c678] text-[#120905] font-semibold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <MessageCircle className="w-4 h-4 fill-current" />
              )}
              <span>{isSubmitting ? 'Preparing WhatsApp...' : 'Send Enquiry via WhatsApp'}</span>
            </button>

            <p className="text-[10px] text-center text-[#d8c2ad]/60">
              Your order reference is saved in this browser. Your order is sent to us when you send the WhatsApp message.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
