import { CartItem, Product } from '../types/chocolate';

export const WHATSAPP_NUMBER = '916386590007';
export const DISPLAY_PHONE = '+91 63865 90007';
export const BRAND_EMAIL = 'thecawnporechocos@gmail.com';
export const BRAND_LOCATION = 'Kanpur, Uttar Pradesh, India';

/**
 * Builds a direct WhatsApp web/app link with URL encoded message
 */
export function buildWhatsAppUrl(message: string): string {
  const encoded = encodeURIComponent(message.trim());
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;
}

/**
 * Pre-filled message for a single product order
 */
export function getProductOrderWhatsAppUrl(product: Product, quantity = 1, customNote = ''): string {
  const total = product.price * quantity;
  const message = `Namaste The Cawnpore Chocos!

I would like to order the following artisanal chocolate:

*Item:* ${product.name}
*Specification:* ${product.weight} · ${product.cocoaPercentage}% Cocoa
*Quantity:* ${quantity}
*Total Value:* ₹${total.toLocaleString('en-IN')}
${customNote ? `*Special Request:* ${customNote}\n` : ''}
Kindly let me know the batch availability, packaging, and dispatch timeline to my city. Thank you!`;

  return buildWhatsAppUrl(message);
}

/**
 * Pre-filled message for multiple items in the enquiry bag
 */
export function getCartOrderWhatsAppUrl(items: CartItem[], customerName = '', deliveryCity = ''): string {
  const grandTotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const itemsList = items
    .map(
      (item, idx) =>
        `${idx + 1}. *${item.product.name}* (${item.product.weight}) × ${item.quantity} = ₹${(
          item.product.price * item.quantity
        ).toLocaleString('en-IN')}`
    )
    .join('\n');

  const message = `Namaste The Cawnpore Chocos!

I would like to enquire about ordering the following selection:

${itemsList}

*Estimated Order Total:* ₹${grandTotal.toLocaleString('en-IN')}
${customerName ? `*Name:* ${customerName}\n` : ''}${deliveryCity ? `*Delivery City:* ${deliveryCity}\n` : ''}
Please confirm availability and dispatch options.`;

  return buildWhatsAppUrl(message);
}

/**
 * Pre-filled message for festive / wedding bulk gifting
 */
export function getFestiveBulkEnquiryUrl(details: {
  occasion: string;
  quantityBoxes?: string;
  preferredRange?: string;
  contactName?: string;
  city?: string;
  targetDate?: string;
  notes?: string;
}): string {
  const message = `Namaste The Cawnpore Chocos!

I would like to enquire about luxury chocolate gifting for *${details.occasion}*:

${details.contactName ? `*Contact Person:* ${details.contactName}\n` : ''}${
    details.city ? `*Delivery Location:* ${details.city}\n` : ''
  }${details.quantityBoxes ? `*Estimated Hamper Quantity:* ${details.quantityBoxes}\n` : ''}${
    details.preferredRange ? `*Budget / Preferred Range:* ${details.preferredRange}\n` : ''
  }${details.targetDate ? `*Required Delivery Date:* ${details.targetDate}\n` : ''}${
    details.notes ? `*Custom Requirements:* ${details.notes}\n` : ''
  }
Please share custom curation options and corporate/wedding catalog details.`;

  return buildWhatsAppUrl(message);
}
