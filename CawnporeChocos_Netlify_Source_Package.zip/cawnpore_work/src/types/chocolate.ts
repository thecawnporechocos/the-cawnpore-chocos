export type ProductCategory = 
  | 'all'
  | 'dark-single-origin'
  | 'bonbons-truffles'
  | 'indian-infusions'
  | 'milk-nuts'
  | 'gift-hampers'
  | 'festive-specials';

export type FestivalTag = 
  | 'diwali'
  | 'christmas'
  | 'birthday'
  | 'weddings'
  | 'anniversary'
  | 'roka'
  | 'childrens-day'
  | 'all-occasions';

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: ProductCategory;
  price: number; // in INR
  cocoaPercentage: number; // e.g. 72, 85, 55, 38
  weight: string; // e.g. "150g", "240g", "12 Pcs"
  piecesCount?: number;
  image: string;
  tastingNotes: string[];
  description: string;
  ingredients: string;
  dietary: string; // e.g. "100% Vegetarian (Eggless) · Pure Cocoa Butter"
  shelfLife: string; // e.g. "90 Days from dispatch"
  festivals?: FestivalTag[];
  isFeatured?: boolean;
  isBestseller?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  customNote?: string;
}

export interface FestivalCollection {
  id: FestivalTag;
  title: string;
  tagline: string;
  badge: string;
  description: string;
  heroImage: string;
  curatedProducts: string[]; // product IDs
  highlightFeatures: string[];
}
