import { FestivalCollection, Product } from '../types/chocolate';

// Authentic Brand Assets provided directly by The Cawnpore Chocos
export const BRAND_LOGO = '/assets/aistudio/b98e282f-669f-4e25-8d89-8108452098c8_1f146091.jpeg';
export const STOREFRONT_IMAGE = '/assets/aistudio/AA082B72-BAC3-43DF-BAFA-67A32D4C3568_3cf912c7.jpeg';
export const KANPUR_AERIAL_IMAGE = '/assets/aistudio/FEC5F515-3188-45EB-AA6F-6F21F170A6F0_5ec0d247.jpeg';
export const ROYAL_HAMPER_IMAGE = '/assets/aistudio/FEC5F515-3188-45EB-AA6F-6F21F170A6F0_1185a598.jpeg';
export const CELEBRATION_BOXES_IMAGE = '/assets/aistudio/IMG_8568_5544d1b9.jpeg';
export const DIWALI_REAL_BOX_IMAGE = '/assets/aistudio/0E8EE2C7-DDB0-4798-948A-4B2C68995C1D_97d8e003.jpeg';

// Clean Confectionery Food Photography (Unbranded & 100% Text-Free, overlaid via UI)
export const HERO_LUXURY_SLABS = '/assets/images/hero_cawnpore_luxury_1793961977286.jpg';
export const CHRISTMAS_TRUFFLES = '/assets/images/christmas_winter_chocolates_1793961976111.jpg';
export const BIRTHDAY_BONBONS = '/assets/images/birthday_celebration_box_1793961977757.jpg';
export const CHILDRENS_CLUSTERS = '/assets/images/childrens_day_clusters_1793961977339.jpg';
export const ROKA_CEREMONY_TRAY = '/assets/images/roka_ceremony_hamper_1793962053725.jpg';

// Backward-compatible exports for existing imports
export const HERO_IMAGE = HERO_LUXURY_SLABS;
export const HAMPER_IMAGE = ROYAL_HAMPER_IMAGE;
export const DIWALI_IMAGE = DIWALI_REAL_BOX_IMAGE;
export const BONBONS_IMAGE = BIRTHDAY_BONBONS;
export const CRAFT_IMAGE = STOREFRONT_IMAGE;

export const PRODUCTS: Product[] = [
  // 1. Core Single Piece & Special Chocolates (Exact Pricing Requested by Customer)
  {
    id: 'classic-milk-chocolate',
    name: 'Classic Milk Chocolate',
    subtitle: 'Creamy Smooth Milk Chocolate Piece',
    category: 'milk-nuts',
    price: 30,
    cocoaPercentage: 38,
    weight: '1 Piece · 18g',
    piecesCount: 1,
    image: CHILDRENS_CLUSTERS,
    tastingNotes: ['Creamy Milk', 'Caramel Sweetness', 'Silky Melt'],
    description: 'Silky smooth classic milk chocolate piece handcrafted in Kanpur using pure cocoa butter. 100% vegetarian, eggless, and free from palm oil. Popular choice for daily treats and birthday return gifts.',
    ingredients: 'Pure Cocoa Butter, Milk Powder, Cocoa Mass, Raw Cane Sugar, Natural Vanilla.',
    dietary: '100% Vegetarian (Eggless) · Pure Cocoa Butter',
    shelfLife: '90 Days from dispatch',
    festivals: ['birthday', 'childrens-day', 'all-occasions'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'rich-dark-chocolate',
    name: 'Rich Dark Chocolate',
    subtitle: 'Decadent 70% Dark Cocoa Piece',
    category: 'dark-single-origin',
    price: 35,
    cocoaPercentage: 70,
    weight: '1 Piece · 18g',
    piecesCount: 1,
    image: HERO_LUXURY_SLABS,
    tastingNotes: ['Deep Cocoa', 'Bittersweet Cacao', 'Warm Molasses'],
    description: 'Decadent 70% dark chocolate piece crafted for dark chocolate purists in Kanpur. Made with stone-ground cocoa beans and pure cocoa butter without palm oil.',
    ingredients: 'Single-Origin Cocoa Beans (70%), Pure Cocoa Butter, Unrefined Cane Sugar.',
    dietary: '100% Vegetarian (Eggless) · Gluten Free',
    shelfLife: '120 Days from dispatch',
    festivals: ['all-occasions', 'christmas'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'crunchy-nut-chocolate',
    name: 'Crunchy Nut Chocolate',
    subtitle: 'Roasted Almond & Cashew Nut Chocolate Piece',
    category: 'milk-nuts',
    price: 40,
    cocoaPercentage: 55,
    weight: '1 Piece · 22g',
    piecesCount: 1,
    image: CELEBRATION_BOXES_IMAGE,
    tastingNotes: ['Oven-Roasted Almonds', 'Toasted Cashew', 'Balanced Cacao'],
    description: 'Delicious chocolate piece loaded with oven-roasted California almonds and cashews. One of our most popular homemade chocolates in Kanpur.',
    ingredients: 'Cocoa Mass, Cocoa Butter, Whole Roasted Almonds, Cashews, Raw Sugar.',
    dietary: '100% Vegetarian (Eggless) · High Protein Nut Bite',
    shelfLife: '90 Days from dispatch',
    festivals: ['all-occasions', 'diwali', 'birthday'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'biscoff-chocolate',
    name: 'Biscoff Chocolate',
    subtitle: 'Spiced Speculoos Cookie Cream & Crunch Piece',
    category: 'bonbons-truffles',
    price: 50,
    cocoaPercentage: 45,
    weight: '1 Piece · 24g',
    piecesCount: 1,
    image: BIRTHDAY_BONBONS,
    tastingNotes: ['Spiced Caramel Cookie', 'Speculoos Cream', 'Milk Chocolate Shell'],
    description: 'Irresistible chocolate piece filled with caramelized Lotus Biscoff speculoos spread and crunchy biscuit bits. A signature delight from The Cawnpore Chocos.',
    ingredients: 'Milk Chocolate, Cocoa Butter, Biscoff Speculoos Cream, Caramelized Wheat Biscuits, Cinnamon.',
    dietary: '100% Vegetarian (Eggless) · Gourmet Filling',
    shelfLife: '60 Days from dispatch',
    festivals: ['all-occasions', 'birthday', 'christmas'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'kunafa-chocolate',
    name: 'Kunafa Chocolate',
    subtitle: 'Crispy Roasted Kataifi Pastry & Creamy Pistachio Piece',
    category: 'indian-infusions',
    price: 60,
    cocoaPercentage: 52,
    weight: '1 Piece · 28g',
    piecesCount: 1,
    image: DIWALI_REAL_BOX_IMAGE,
    tastingNotes: ['Toasted Kunafa Kataifi', 'Creamy Pistachio Praline', 'Rich Milk Cocoa'],
    description: 'The world-famous viral Kunafa chocolate recreated by The Cawnpore Chocos in Kanpur. Crisp butter-roasted kataifi pastry combined with rich pistachio ganache inside a silky chocolate shell.',
    ingredients: 'Pure Cocoa Butter, Milk Solids, Pistachio Cream, Butter-Roasted Kataifi Pastry, Cane Sugar.',
    dietary: '100% Vegetarian (Eggless) · Artisanal Recipe',
    shelfLife: '45 Days from dispatch',
    festivals: ['diwali', 'weddings', 'roka', 'all-occasions'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'premium-special-chocolates',
    name: 'Premium Special Chocolates (24K Gold & Saffron)',
    subtitle: 'Edible Gold Leaf & Kashmiri Saffron Infused Medallion',
    category: 'bonbons-truffles',
    price: 70,
    cocoaPercentage: 68,
    weight: '1 Piece · 25g',
    piecesCount: 1,
    image: ROYAL_HAMPER_IMAGE,
    tastingNotes: ['24K Gold Leaf', 'Kashmiri Kesar', 'Iranian Pistachio'],
    description: 'Our flagship premium special chocolate piece gilded with 24K edible gold leaf and steeped with authentic Kashmiri saffron strands. Perfect for grand Kanpur chocolate gift hampers.',
    ingredients: 'Cocoa Mass, Cocoa Butter, Kashmiri Saffron, Green Cardamom, Edible 24K Gold Leaf, Pistachio.',
    dietary: '100% Vegetarian (Eggless) · 24K Gold Leaf',
    shelfLife: '60 Days from dispatch',
    festivals: ['diwali', 'weddings', 'roka', 'anniversary'],
    isFeatured: true,
    isBestseller: true,
  },

  // 2. Real Gift Hampers & Festive Collections
  {
    id: 'jewel-bonbon-assortment',
    name: 'The Cawnpore Signature Jewel Bonbons',
    subtitle: 'Hand-Painted Cocoa Butter Shells with Silken Ganache',
    category: 'bonbons-truffles',
    price: 1160,
    cocoaPercentage: 68,
    weight: '220g · 12 Handcrafted Bonbons',
    piecesCount: 12,
    image: BIRTHDAY_BONBONS,
    tastingNotes: ['Espresso Ganache', 'Salted Dulce Caramel', 'Ruby Passionfruit', 'Spiced Cinnamon'],
    description: 'A vibrant collection of jewel-toned bonbons hand-painted with colored cocoa butter. Handcrafted homemade chocolates in Kanpur for birthdays, anniversaries, and luxury gifting.',
    ingredients: 'Dark Chocolate (68%), Milk Chocolate (38%), Cocoa Butter, Natural Fruit Purees, Coffee Beans, Cream, Sea Salt.',
    dietary: '100% Vegetarian (Eggless) · Micro-Batch Handcrafted',
    shelfLife: '45 Days from dispatch',
    festivals: ['christmas', 'diwali', 'birthday', 'anniversary', 'all-occasions'],
    isFeatured: true,
  },
  {
    id: 'festive-deepavali-box',
    name: 'Subh Deepavali Shahi Confection Box',
    subtitle: 'Royal Festive Hamper with Handcrafted Medallions & Dry Fruit Truffles',
    category: 'festive-specials',
    price: 1860,
    cocoaPercentage: 60,
    weight: '380g · 18 Festive Delights',
    piecesCount: 18,
    image: DIWALI_REAL_BOX_IMAGE,
    tastingNotes: ['Rose Marzipan', 'Kesar Pistachio Slabs', 'Roasted Cashew Ganache'],
    description: 'Crafted specially for Diwali home celebrations and corporate gifting. Features traditional mithai flavors elevated into European artisanal chocolate in authentic branded Cawnpore Chocos packaging.',
    ingredients: 'Cocoa Butter, Cocoa Mass, Kashmiri Saffron, Green Cardamom, Almond Flour, Roasted Cashews, Pistachios.',
    dietary: '100% Vegetarian (Eggless) · Festive Gift Pack',
    shelfLife: '60 Days from dispatch',
    festivals: ['diwali'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'royal-heritage-hamper',
    name: 'The Royal Cawnpore Heritage Hamper Box',
    subtitle: 'Opulent Rigid Chocolate Box with Satin Ribbon & Gold Foil',
    category: 'gift-hampers',
    price: 2460,
    cocoaPercentage: 65,
    weight: '450g · 24 Assorted Confections',
    piecesCount: 24,
    image: ROYAL_HAMPER_IMAGE,
    tastingNotes: ['Pralines', 'Florentines', 'Roasted Rochers', 'Dark Truffles'],
    description: 'Our crown jewel gift box crafted for grand Indian festivities and wedding gifting. Deep chocolate brown rigid box with hot-stamped gold foil The Cawnpore Chocos insignia.',
    ingredients: 'Single-Origin Cocoa Mass, Cocoa Butter, Mamra Almonds, Hazelnuts, Pistachios, Cardamom, Cane Sugar.',
    dietary: '100% Vegetarian (Eggless) · Luxury Keepsake Box',
    shelfLife: '60 Days from dispatch',
    festivals: ['diwali', 'weddings', 'anniversary', 'all-occasions'],
    isFeatured: true,
    isBestseller: true,
  },
  {
    id: 'anniversary-celebration-box',
    name: 'Celebration Moments Ribbon Gift Box',
    subtitle: 'Pink & Gold Elegance Box with Custom Artisan Chocolate Squares',
    category: 'gift-hampers',
    price: 1460,
    cocoaPercentage: 62,
    weight: '300g · 16 Confections',
    piecesCount: 16,
    image: CELEBRATION_BOXES_IMAGE,
    tastingNotes: ['Roasted Nuts', 'Silken Milk Praline', 'Dark Caramel'],
    description: 'Delightful celebration boxes tied with golden yellow bows, featuring individually branded Cawnpore Chocos chocolate squares. Premium Kanpur chocolate gift hampers for anniversaries and birthdays.',
    ingredients: 'Cocoa Butter, Milk Solids, Hazelnut Praline, Roasted Almonds, Brown Sugar.',
    dietary: '100% Vegetarian (Eggless) · Signature Bow Packaging',
    shelfLife: '60 Days from dispatch',
    festivals: ['anniversary', 'birthday', 'all-occasions'],
    isFeatured: true,
  },
  {
    id: 'roka-sagan-celebration-tray',
    name: 'Royal Roka & Sagan Ceremony Chocolate Platter',
    subtitle: 'Opulent Brass Inlay Wooden Tray with Edible Rose & Gold Chocolates',
    category: 'gift-hampers',
    price: 2960,
    cocoaPercentage: 68,
    weight: '520g · 28 Luxury Confections',
    piecesCount: 28,
    image: ROKA_CEREMONY_TRAY,
    tastingNotes: ['Edible Gold Truffles', 'Damask Rose Ganache', 'Pistachio Gianduja'],
    description: 'The definitive confection tray for Roka and Sagan ceremonies. Hand-carved decorative wooden platter overflowing with artisanal chocolates, dried rose petals, whole dry fruits, and gold leaf medallions.',
    ingredients: 'Pure Cocoa Mass, Cocoa Butter, Dried Damask Rose, Kashmiri Saffron, Mamra Almonds, Pistachios.',
    dietary: '100% Vegetarian (Eggless) · Keepsake Royal Platter',
    shelfLife: '45 Days from dispatch',
    festivals: ['roka', 'weddings'],
    isFeatured: true,
  },
  {
    id: 'bespoke-wedding-trousseau-trunk',
    name: 'The Awadh Wedding Trousseau Gifting Trunk',
    subtitle: 'Handmade Velvet & Brass Clasp Gift Box with 36 Luxury Truffles',
    category: 'gift-hampers',
    price: 3610,
    cocoaPercentage: 66,
    weight: '680g · 36 Truffles & Pralines',
    piecesCount: 36,
    image: ROYAL_HAMPER_IMAGE,
    tastingNotes: ['Assorted Signature Flavors', 'Gold Leaf Truffles', 'Pistachio Gianduja'],
    description: 'Designed exclusively for Indian wedding invitations and bridal return favors in Kanpur and UP. Custom satin ribbons and personalized monogram cards with The Cawnpore Chocos seal.',
    ingredients: 'Finest Cocoa Beans, Cocoa Butter, Whole Dry Fruits, Saffron, Cardamom, Vanilla, Cream, Cane Sugar.',
    dietary: '100% Vegetarian (Eggless) · Bespoke Packaging',
    shelfLife: '60 Days from dispatch',
    festivals: ['weddings'],
    isFeatured: true,
  }
];

export const FESTIVAL_COLLECTIONS: FestivalCollection[] = [
  {
    id: 'diwali',
    title: 'The Grand Diwali Collection',
    tagline: 'Illuminating celebrations with Awadh-inspired chocolate craftsmanship.',
    badge: 'Festive Bestseller',
    description: 'Celebrate Diwali with our handcrafted Kunafa chocolates, 24K gold-dusted truffles, and opulent royal Kanpur chocolate gift hampers. 100% vegetarian and freshly prepared in small batches.',
    heroImage: DIWALI_REAL_BOX_IMAGE,
    curatedProducts: ['festive-deepavali-box', 'kunafa-chocolate', 'premium-special-chocolates', 'royal-heritage-hamper'],
    highlightFeatures: [
      'Pure Cocoa Butter (No vegetable fats or vanaspati)',
      '100% Vegetarian & Eggless recipe',
      'Authentic The Cawnpore Chocos embossed gold lid boxes',
      'Fresh express delivery across Kanpur & Uttar Pradesh'
    ]
  },
  {
    id: 'christmas',
    title: 'Christmas & Winter Holiday Edition',
    tagline: 'Warm spiced Biscoff, cinnamon pralines and festive chocolate gift boxes.',
    badge: 'Winter Festive',
    description: 'Evoke holiday warmth with Biscoff Speculoos chocolates, rich dark cocoa pieces, and festive ribbon-tied gift assortments in Kanpur.',
    heroImage: CHRISTMAS_TRUFFLES,
    curatedProducts: ['biscoff-chocolate', 'rich-dark-chocolate', 'jewel-bonbon-assortment'],
    highlightFeatures: [
      'Artisanal European chocolate making traditions',
      'Festive satin ribbon presentation & gift tags',
      'Customizable holiday message cards included'
    ]
  },
  {
    id: 'birthday',
    title: 'Birthday Celebration Collections',
    tagline: 'Joyful homemade chocolates in Kanpur made to make their day extraordinary.',
    badge: 'Celebration Delight',
    description: 'Make birthdays in Kanpur truly memorable with Biscoff bites, Crunchy Nut chocolates, jewel-toned bonbons, and custom message cards.',
    heroImage: BIRTHDAY_BONBONS,
    curatedProducts: ['classic-milk-chocolate', 'crunchy-nut-chocolate', 'biscoff-chocolate', 'anniversary-celebration-box'],
    highlightFeatures: [
      'Complimentary personalized birthday card inside',
      'Exquisite hand-painted bonbons & crunchy nut chocolates',
      'Same-day express delivery coordination within Kanpur'
    ]
  },
  {
    id: 'weddings',
    title: 'Weddings & Royal Occasions',
    tagline: 'Bespoke chocolate trousseau boxes & personalized return favors in Kanpur.',
    badge: 'Royal Celebrations',
    description: 'Imprint your momentous day with the timeless taste of Cawnpore luxury chocolates. From Kunafa treats to 36-piece wedding trousseau gift trunks.',
    heroImage: ROYAL_HAMPER_IMAGE,
    curatedProducts: ['bespoke-wedding-trousseau-trunk', 'royal-heritage-hamper', 'premium-special-chocolates', 'kunafa-chocolate'],
    highlightFeatures: [
      'Custom rigid box colors, ribbons & foil monograms',
      'Curated tasting flight of Kunafa & 24K gold leaf chocolates',
      'Dedicated wedding concierge via WhatsApp consultation'
    ]
  },
  {
    id: 'anniversary',
    title: 'Anniversary Milestones',
    tagline: 'Cherished memories celebrated in silken cacao and golden ribbons.',
    badge: 'Romantic Moments',
    description: 'Commemorate years of togetherness with our handcrafted Kanpur chocolate gift hampers, presented in ribbon-tied luxury boxes with handwritten parchment notes.',
    heroImage: CELEBRATION_BOXES_IMAGE,
    curatedProducts: ['anniversary-celebration-box', 'premium-special-chocolates', 'jewel-bonbon-assortment', 'royal-heritage-hamper'],
    highlightFeatures: [
      'Hand-tied satin bow boxes with custom anniversary notes',
      'Pure single-origin cocoa with decadent Biscoff & nut fillings',
      'Chilled doorstep delivery to preserve gloss and texture'
    ]
  },
  {
    id: 'roka',
    title: 'Roka & Sagan Ceremony Gifting',
    tagline: 'Traditional Indian engagement platters elevated with chocolate luxury.',
    badge: 'Traditional Sagan',
    description: 'Celebrate the auspicious Roka ceremony with stunning handcrafted confectionery trays featuring Kunafa, real dried roses, roasted pistachios, and 24K gold foil.',
    heroImage: ROKA_CEREMONY_TRAY,
    curatedProducts: ['roka-sagan-celebration-tray', 'kunafa-chocolate', 'royal-heritage-hamper', 'premium-special-chocolates'],
    highlightFeatures: [
      'Grand decorative presentation suitable for auspicious rituals',
      'Kunafa and pure dry fruit infused chocolate medallions',
      'Direct coordination for custom auspicious dates and timings'
    ]
  },
  {
    id: 'childrens-day',
    title: 'Children’s Day Joyful Treats',
    tagline: 'Gentle creamy milk chocolate treats crafted with pure ingredients.',
    badge: 'For Young Palates',
    description: 'Delight the young ones with wholesome Classic Milk Chocolate (₹30), Crunchy Nut chocolates (₹40), and Biscoff bites made without chemical preservatives.',
    heroImage: CHILDRENS_CLUSTERS,
    curatedProducts: ['classic-milk-chocolate', 'crunchy-nut-chocolate', 'biscoff-chocolate'],
    highlightFeatures: [
      'Low bitterness, creamy 38% milk chocolate',
      'Zero palm oil or hydrogenated fats',
      'Crunchy roasted nuts and Biscoff speculoos fillings'
    ]
  }
];
